# 🌐 FF VPN - Real WireGuard VPS Server Deployment Guide
### (বাংলাদেশ, সিঙ্গাপুর, ইন্ডিয়া, ইউএসএ সার্ভার সেটআপ গাইড)

FF VPN আসল WireGuard প্রটোকল ব্যবহার করে। আপনি আপনার নিজের VPS (যেমন: DigitalOcean, Hetzner, AWS, Linode, বা বাংলাদেশের BDIX VPS যেমন XeonBD, Alpha Net) এ সহজেই WireGuard নোড চালু করতে পারেন।

---

## ⚡ ১-ক্লিক অটোমেটিক সার্ভার ইনস্টলেশন (1-Click Auto Installer)

যেকোনো Ubuntu 22.04 / 24.04 বা Debian 12 VPS এ SSH দিয়ে লগইন করুন এবং নিচের কমান্ডটি দিন:

```bash
wget https://git.io/wireguard -O wireguard-install.sh && bash wireguard-install.sh
```

ইনস্টলারটি স্বয়ংক্রিয়ভাবে:
1. সার্ভারের পাবলিক আইপি (`IPv4`) চিহ্নিত করবে।
2. পোর্ট সিলেক্ট করতে বলবে (ডিফল্ট: `51820` UDP)।
3. ক্লায়েন্ট নাম চাইবে (যেমন: `ffvpn-client-1`)।
4. DNS সিলেক্ট করতে বলবে (`1.1.1.1` রিকমেন্ডেড - দ্রুত পিং ও নো প্যাকেট লস)।
5. সার্ভার প্রাইভেট ও পাবলিক কি (`wg0.conf`) স্বয়ংক্রিয়ভাবে জেনারেট করবে।

---

## 🔧 ম্যানুয়াল সার্ভার কনফিগারেশন (`/etc/wireguard/wg0.conf`)

যদি আপনি নিজে হাতে সার্ভার কনফিগার করতে চান:

```ini
[Interface]
Address = 10.8.1.1/24, fd42:42:42::1/64
ListenPort = 51820
PrivateKey = <SERVER_PRIVATE_KEY>
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Client 1 (Example FF VPN User)
[Peer]
PublicKey = <CLIENT_PUBLIC_KEY>
AllowedIPs = 10.8.1.2/32, fd42:42:42::2/128
```

### সার্ভারে IP Forwarding চালু করা:
```bash
echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
echo "net.ipv6.conf.all.forwarding = 1" >> /etc/sysctl.conf
sysctl -p
```

### WireGuard সার্ভিস চালু ও বুট এনেবল করা:
```bash
systemctl enable wg-quick@wg0
systemctl start wg-quick@wg0
```

---

## 🎮 গেমিং পিং কমানোর স্পেশাল টিপস (Free Fire & PUBG Low Ping Tips)

1. **MTU 1280**: মোবাইল ইন্টারনেটে (Grameenphone, Banglalink, Robi, Airtel) প্যাকেট ফ্র্যাগমেন্টেশন রোধ করার জন্য ক্লায়েন্ট MTU সর্বদা `1280` রাখা হয়েছে।
2. **BDIX Server (বাংলাদেশ)**: বাংলাদেশে ফ্রি ফায়ার পিং ১৫-২০ মিলি সেকেন্ডের মধ্যে রাখতে একটি BDIX কানেক্টেড লোকাল সার্ভার ব্যবহার করুন।
3. **সিঙ্গাপুর নোড**: সিঙ্গাপুর সার্ভারে সাধারণত SEA (South East Asia) গেম রিজিয়নের সাথে ডিরেক্ট ফাইবার অপটিক ক্যাবল রাউটিং থাকে, যার ফলে পিং ৩২-৩৮ms স্থিতিশীল থাকে।

---

## 📲 FF VPN অ্যাপে নতুন সার্ভার যোগ করবেন কীভাবে?

1. অ্যাপের ভেতরে গিয়ে **Admin Panel** ওপেন করুন (পাসকোড: `ffvpn2026`)।
2. **Server Management** ট্যাবে যান।
3. **Add New Server** চাপুন।
4. আপনার সার্ভারের নাম, দেশের ফ্ল্যাগ, আইপি:পোর্ট (যেমন: `203.0.113.10:51820`), এবং WireGuard Server Public Key পেস্ট করে Save চাপুন।
5. সাথে সাথে সব অ্যাপ ব্যবহারকারী আপনার নতুন সার্ভারটি দেখতে পাবে এবং কানেক্ট করতে পারবে!
