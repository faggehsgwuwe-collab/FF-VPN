import React, { useState, useEffect, useRef } from 'react';
import {
  ConnectionState,
  Language,
  TrafficStats,
  UserProfile,
  VpnServer,
} from './types/vpn';
import { translations } from './locales/translations';
import {
  initServersStorage,
  getOrCreateUserProfile,
  saveUserProfile,
} from './services/firebase';
import { WireGuardNative, isNativeAndroid } from './services/wireguardPlugin';
import { buildWireGuardConfig, formatWireGuardConfigFile } from './services/wireguardConfig';
import { Header } from './components/Header';
import { ConnectButton } from './components/ConnectButton';
import { StatsDashboard } from './components/StatsDashboard';
import { ServerSelector } from './components/ServerSelector';
import { ServerModal } from './components/ServerModal';
import { PremiumModal } from './components/PremiumModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { TermuxGuideModal } from './components/TermuxGuideModal';
import { NativeVpnStatusBanner } from './components/NativeVpnStatusBanner';
import { Flame, Gamepad2, Sparkles, Shield, Wifi, RefreshCw } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('bn');
  const [servers, setServers] = useState<VpnServer[]>([]);
  const [activeServer, setActiveServer] = useState<VpnServer | null>(null);
  const [user, setUser] = useState<UserProfile>(getOrCreateUserProfile());
  const [connectionState, setConnectionState] = useState<ConnectionState>('DISCONNECTED');
  const [durationSeconds, setDurationSeconds] = useState(0);

  const [stats, setStats] = useState<TrafficStats>({
    bytesIn: 0,
    bytesOut: 0,
    downloadSpeed: 0,
    uploadSpeed: 0,
    durationSeconds: 0,
    latencyMs: 18,
    packetLoss: 0,
    ipAddress: 'Disconnected',
  });

  // Modals state
  const [isServerModalOpen, setIsServerModalOpen] = useState(false);
  const [isPremiumModalOpen, setIsPremiumModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isTermuxGuideOpen, setIsTermuxGuideOpen] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const speedIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize servers & user
  useEffect(() => {
    const loadedServers = initServersStorage();
    setServers(loadedServers);
    // Default to Bangladesh or Singapore low ping
    const defaultServer =
      loadedServers.find((s) => s.countryCode === 'BD' && !s.isPremium) ||
      loadedServers[0];
    setActiveServer(defaultServer);
    setUser(getOrCreateUserProfile());
  }, []);

  // Update ping periodically for active server
  useEffect(() => {
    if (!activeServer) return;
    const interval = setInterval(async () => {
      try {
        const res = await WireGuardNative.pingServer({
          host: activeServer.endpoint.split(':')[0],
          port: 53,
        });
        if (res.latencyMs > 0 && res.latencyMs < 999) {
          setStats((prev) => ({
            ...prev,
            latencyMs: res.latencyMs,
          }));
        }
      } catch {
        // keep existing latency
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [activeServer]);

  // Traffic counter simulation & poll
  useEffect(() => {
    if (connectionState === 'CONNECTED') {
      timerRef.current = setInterval(() => {
        setDurationSeconds((d) => d + 1);
      }, 1000);

      speedIntervalRef.current = setInterval(async () => {
        if (isNativeAndroid()) {
          try {
            const nativeStatus = await WireGuardNative.getStatus();
            setStats(nativeStatus.traffic);
            return;
          } catch {
            // fallback to dynamic counters
          }
        }

        // Realistic low-ping gaming traffic jitter
        setStats((prev) => {
          const downDelta = Math.floor(Math.random() * 800000) + 1200000;
          const upDelta = Math.floor(Math.random() * 300000) + 400000;
          const basePing = activeServer ? activeServer.ping : 22;
          const jitter = Math.floor(Math.random() * 5) - 2;

          return {
            ...prev,
            bytesIn: prev.bytesIn + downDelta,
            bytesOut: prev.bytesOut + upDelta,
            downloadSpeed: downDelta,
            uploadSpeed: upDelta,
            latencyMs: Math.max(12, basePing + jitter),
            packetLoss: 0,
            ipAddress: activeServer ? `10.8.${activeServer.isPremium ? '2' : '1'}.142` : '10.8.1.142',
          };
        });
      }, 1200);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      if (speedIntervalRef.current) clearInterval(speedIntervalRef.current);
      setDurationSeconds(0);
      setStats((prev) => ({
        ...prev,
        downloadSpeed: 0,
        uploadSpeed: 0,
        ipAddress: 'Disconnected',
      }));
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (speedIntervalRef.current) clearInterval(speedIntervalRef.current);
    };
  }, [connectionState, activeServer]);

  // Handle Connect / Disconnect
  const handleToggleConnect = async () => {
    if (!activeServer) return;

    if (connectionState === 'CONNECTED') {
      setConnectionState('DISCONNECTING');
      try {
        await WireGuardNative.disconnect();
      } catch (err) {
        console.error('Failed to disconnect:', err);
      } finally {
        setTimeout(() => {
          setConnectionState('DISCONNECTED');
        }, 600);
      }
      return;
    }

    // Check VIP permission if server is VIP
    if (activeServer.isPremium && !user.isPremium) {
      setIsPremiumModalOpen(true);
      return;
    }

    setConnectionState('CONNECTING');

    try {
      // 1. Prepare Android VpnService permission
      const prep = await WireGuardNative.prepareVpn();
      console.log('VPN Prepare result:', prep);

      // 2. Build WireGuard Configuration
      const config = buildWireGuardConfig(activeServer);
      const configText = formatWireGuardConfigFile(config);

      // 3. Connect via Native WireGuard Tunnel
      const result = await WireGuardNative.connect({
        tunnelName: `FF-${activeServer.countryCode}`,
        configText,
        serverEndpoint: activeServer.endpoint,
      });

      console.log('WireGuard Connect result:', result);

      setTimeout(() => {
        setConnectionState('CONNECTED');
        setStats((prev) => ({
          ...prev,
          latencyMs: activeServer.ping,
          ipAddress: config.clientAddress.split('/')[0],
        }));
      }, 1000);
    } catch (err: any) {
      console.error('Connection error:', err);
      alert(`WireGuard connection failed: ${err?.message || 'Error initializing tunnel'}`);
      setConnectionState('DISCONNECTED');
    }
  };

  const handleRefreshUser = () => {
    setUser(getOrCreateUserProfile());
  };

  const handleUpdateServers = (updated: VpnServer[]) => {
    setServers(updated);
    if (activeServer) {
      const stillExists = updated.find((s) => s.id === activeServer.id);
      if (stillExists) setActiveServer(stillExists);
      else setActiveServer(updated[0]);
    }
  };

  const t = translations[lang];

  return (
    <div className="min-h-screen bg-[#05080A] text-white flex flex-col justify-between max-w-md mx-auto relative overflow-hidden shadow-2xl border-x border-gray-900">
      {/* Background Cyber Grid Accent */}
      <div className="absolute inset-0 bg-[radial-gradient(#00FF66_1px,transparent_1px)] [background-size:24px_24px] opacity-[0.04] pointer-events-none" />

      {/* Top Header */}
      <Header
        lang={lang}
        onToggleLang={() => setLang((l) => (l === 'bn' ? 'en' : 'bn'))}
        user={user}
        onOpenPremium={() => setIsPremiumModalOpen(true)}
        onOpenAdmin={() => setIsAdminModalOpen(true)}
        onOpenTermuxGuide={() => setIsTermuxGuideOpen(true)}
      />

      {/* Main VPN Interactive Zone */}
      <main className="flex-1 flex flex-col items-center justify-between py-2 relative z-10">
        {/* Native Architecture Banner */}
        {activeServer && <NativeVpnStatusBanner activeServer={activeServer} />}

        {/* Server Selector Card */}
        {activeServer && (
          <ServerSelector
            server={activeServer}
            onOpenModal={() => setIsServerModalOpen(true)}
            lang={lang}
          />
        )}

        {/* Center Glowing Connect Radar Button */}
        <ConnectButton
          state={connectionState}
          onToggle={handleToggleConnect}
          lang={lang}
          durationSeconds={durationSeconds}
        />

        {/* Real-time Gaming Telemetry Dashboard */}
        {activeServer && (
          <StatsDashboard
            stats={stats}
            state={connectionState}
            activeServer={activeServer}
            lang={lang}
          />
        )}

        {/* Free Fire Gaming Optimization Tips */}
        <div className="w-full px-4 mb-2">
          <div className="p-2.5 rounded-xl bg-gradient-to-r from-gray-950 via-[#0B1015] to-gray-950 border border-gray-800/90 flex items-center justify-between text-left text-xs">
            <div className="flex items-center space-x-2">
              <div className="p-1 rounded bg-amber-500/10 text-amber-400">
                <Gamepad2 className="w-4 h-4" />
              </div>
              <div>
                <span className="font-gaming font-bold text-gray-200">
                  {lang === 'bn' ? 'ফ্রি ফায়ার অপটিমাইজেশন' : 'Free Fire Gaming Booster'}
                </span>
                <p className="text-[10px] text-gray-400">
                  {lang === 'bn'
                    ? 'BDIX ও সিঙ্গাপুর রুটে পিং জাম্প বন্ধ থাকে'
                    : 'UDP Fast Path & Jitter-free buffer active'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsTermuxGuideOpen(true)}
              className="px-2 py-1 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-[#00FF66] font-gaming font-bold text-[11px] border border-emerald-500/30 transition-colors"
            >
              {lang === 'bn' ? 'APK গাইড' : 'APK Guide'}
            </button>
          </div>
        </div>
      </main>

      {/* Bottom Footer Credits */}
      <footer className="w-full py-2.5 px-4 border-t border-gray-900 bg-[#05080A] text-center text-[10px] text-gray-500 flex items-center justify-between font-mono-code">
        <span>FF VPN • WireGuard v1.0</span>
        <button
          onClick={() => setIsAdminModalOpen(true)}
          className="text-gray-500 hover:text-emerald-400 underline transition-colors"
        >
          Admin Portal (01770110154)
        </button>
      </footer>

      {/* Modals */}
      {activeServer && (
        <ServerModal
          isOpen={isServerModalOpen}
          onClose={() => setIsServerModalOpen(false)}
          servers={servers}
          activeServer={activeServer}
          onSelectServer={(srv) => {
            setActiveServer(srv);
            if (connectionState === 'CONNECTED') {
              // reconnect with new server
              handleToggleConnect();
            }
          }}
          user={user}
          onOpenPremium={() => setIsPremiumModalOpen(true)}
          lang={lang}
        />
      )}

      <PremiumModal
        isOpen={isPremiumModalOpen}
        onClose={() => setIsPremiumModalOpen(false)}
        user={user}
        onRefreshUser={handleRefreshUser}
        lang={lang}
      />

      <AdminPanelModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        servers={servers}
        onUpdateServers={handleUpdateServers}
        onRefreshData={handleRefreshUser}
        lang={lang}
      />

      <TermuxGuideModal
        isOpen={isTermuxGuideOpen}
        onClose={() => setIsTermuxGuideOpen(false)}
        lang={lang}
      />
    </div>
  );
}
