export type Language = 'bn' | 'en';

export type ConnectionState =
  | 'DISCONNECTED'
  | 'CONNECTING'
  | 'CONNECTED'
  | 'DISCONNECTING'
  | 'ERROR';

export interface VpnServer {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  city: string;
  flag: string;
  endpoint: string; // e.g. "bd1.ffvpn.app:51820"
  port: number;
  serverPublicKey: string;
  allowedIPs: string;
  dns: string;
  ipPool: string; // e.g. "10.8.10.0/24"
  ping: number; // in ms
  load: number; // percentage 0 - 100
  isPremium: boolean;
  gameTag: string; // e.g. "Free Fire BD 18ms", "SEA Low Ping"
  isOnline: boolean;
}

export interface TrafficStats {
  bytesIn: number;
  bytesOut: number;
  downloadSpeed: number; // bytes/sec
  uploadSpeed: number; // bytes/sec
  durationSeconds: number;
  latencyMs: number;
  packetLoss: number; // percentage
  ipAddress: string;
}

export interface WireGuardConfig {
  privateKey: string;
  clientAddress: string;
  dns: string;
  mtu: number;
  serverPublicKey: string;
  endpoint: string;
  allowedIPs: string;
  persistentKeepalive: number;
}

export interface PremiumRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  phoneNumber: string;
  trxId: string;
  amount: number; // 300 BDT
  method: 'bKash';
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
  updatedAt: number;
  adminNote?: string;
}

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  isPremium: boolean;
  premiumExpiry?: number;
  role: 'user' | 'admin';
  connectedDeviceId?: string;
  savedTrx?: string[];
}
