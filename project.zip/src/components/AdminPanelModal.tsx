import React, { useState } from 'react';
import {
  X,
  Shield,
  Check,
  Ban,
  Server,
  Plus,
  Trash2,
  KeyRound,
  FileCode,
  DollarSign,
  Users,
  Copy,
  Download,
  AlertTriangle,
} from 'lucide-react';
import { Language, PremiumRequest, VpnServer } from '../types/vpn';
import { translations } from '../locales/translations';
import {
  getStoredPremiumRequests,
  updatePremiumRequestStatus,
  saveServersStorage,
} from '../services/firebase';
import {
  buildWireGuardConfig,
  formatWireGuardConfigFile,
  generateWireGuardKey,
} from '../services/wireguardConfig';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  servers: VpnServer[];
  onUpdateServers: (servers: VpnServer[]) => void;
  onRefreshData: () => void;
  lang: Language;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  servers,
  onUpdateServers,
  onRefreshData,
  lang,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState('');
  const [activeTab, setActiveTab] = useState<'requests' | 'servers' | 'wireguard'>('requests');

  // New server form state
  const [newServerName, setNewServerName] = useState('');
  const [newServerCountry, setNewServerCountry] = useState('Bangladesh');
  const [newServerCity, setNewServerCity] = useState('Dhaka');
  const [newServerFlag, setNewServerFlag] = useState('🇧🇩');
  const [newServerEndpoint, setNewServerEndpoint] = useState('bd-new.ffvpn.app:51820');
  const [newServerKey, setNewServerKey] = useState('');
  const [newServerIsVip, setNewServerIsVip] = useState(false);
  const [newServerGameTag, setNewServerGameTag] = useState('Free Fire 15ms VIP');

  // WireGuard preview state
  const [selectedServerForWg, setSelectedServerForWg] = useState<VpnServer>(servers[0] || {} as any);
  const [copiedWg, setCopiedWg] = useState(false);

  const t = translations[lang];

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode.trim() === 'ffvpn2026' || passcode.trim() === 'admin123') {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError(lang === 'bn' ? 'ভুল পাসকোড! ডিফল্ট: ffvpn2026' : 'Invalid Passcode! Default: ffvpn2026');
    }
  };

  const requests = getStoredPremiumRequests();
  const pendingRequests = requests.filter((r) => r.status === 'pending');
  const approvedRequests = requests.filter((r) => r.status === 'approved');
  const totalRevenue = approvedRequests.length * 300;

  const handleApprove = (requestId: string) => {
    updatePremiumRequestStatus(requestId, 'approved', 'Verified via bKash 01770110154 statement', 30);
    onRefreshData();
  };

  const handleReject = (requestId: string) => {
    const reason = prompt('Enter rejection reason (e.g. Invalid TrxID or Amount not received):') || 'Payment not found in statement';
    updatePremiumRequestStatus(requestId, 'rejected', reason);
    onRefreshData();
  };

  const handleAddServer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServerName || !newServerEndpoint) return;

    const server: VpnServer = {
      id: 'srv_' + Date.now().toString(36),
      name: newServerName,
      country: newServerCountry,
      countryCode: newServerCountry === 'Bangladesh' ? 'BD' : 'SG',
      city: newServerCity,
      flag: newServerFlag,
      endpoint: newServerEndpoint,
      port: 51820,
      serverPublicKey: newServerKey || generateWireGuardKey(),
      allowedIPs: '0.0.0.0/0, ::/0',
      dns: '1.1.1.1, 8.8.8.8',
      ipPool: '10.8.20.0/24',
      ping: Math.floor(Math.random() * 25) + 15,
      load: 12,
      isPremium: newServerIsVip,
      gameTag: newServerGameTag,
      isOnline: true,
    };

    const updated = [server, ...servers];
    onUpdateServers(updated);
    saveServersStorage(updated);

    // Reset form
    setNewServerName('');
    setNewServerEndpoint('');
    setNewServerKey('');
    alert('Server added successfully!');
  };

  const handleDeleteServer = (id: string) => {
    if (confirm('Are you sure you want to remove this VPN server node?')) {
      const updated = servers.filter((s) => s.id !== id);
      onUpdateServers(updated);
      saveServersStorage(updated);
    }
  };

  const currentWgConfig = selectedServerForWg?.id
    ? formatWireGuardConfigFile(buildWireGuardConfig(selectedServerForWg))
    : '';

  const handleCopyWgConfig = () => {
    if (navigator.clipboard && currentWgConfig) {
      navigator.clipboard.writeText(currentWgConfig);
      setCopiedWg(true);
      setTimeout(() => setCopiedWg(false), 2000);
    }
  };

  const handleDownloadConf = () => {
    if (!currentWgConfig) return;
    const blob = new Blob([currentWgConfig], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedServerForWg.id || 'ffvpn'}.conf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#070B0E] border border-gray-800 rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Bar */}
        <div className="px-5 py-4 border-b border-gray-800 flex items-center justify-between bg-[#0B1015]">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
              <Shield className="w-5 h-5 text-[#00FF66]" />
            </div>
            <div>
              <h2 className="font-gaming font-extrabold text-base text-white tracking-wide">
                FF VPN Admin Control Center
              </h2>
              <p className="text-[11px] text-gray-400">bKash Verification & WireGuard Fleet</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Authentication Wall */}
        {!isAuthenticated ? (
          <div className="p-6 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-gray-900 border border-gray-700/80 flex items-center justify-center">
              <KeyRound className="w-7 h-7 text-[#00FF66]" />
            </div>

            <div>
              <h3 className="font-gaming font-bold text-lg text-white">
                {t.adminLogin}
              </h3>
              <p className="text-xs text-gray-400 max-w-xs mt-1">
                Enter your administrative key to manage bKash subscriptions and VPN servers.
              </p>
            </div>

            <form onSubmit={handleLogin} className="w-full max-w-xs space-y-3">
              <div>
                <input
                  type="password"
                  placeholder={t.adminPasswordPlaceholder}
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className="w-full px-4 py-2.5 bg-black border border-gray-700 rounded-xl text-center font-mono-code text-sm text-gray-100 placeholder-gray-600 focus:outline-none focus:border-emerald-500"
                  autoFocus
                />
                {authError && (
                  <p className="text-xs text-red-400 font-mono-code mt-1.5">{authError}</p>
                )}
                <p className="text-[10px] text-gray-500 font-mono-code mt-1">
                  Default Passcode: <span className="text-emerald-400">ffvpn2026</span>
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#00FF66] hover:bg-emerald-400 text-black font-gaming font-extrabold text-sm shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
              >
                {t.adminEnter}
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* Overview Quick Stats */}
            <div className="p-4 grid grid-cols-4 gap-2 bg-[#0A0E13] border-b border-gray-800 text-left">
              <div className="p-2.5 rounded-lg bg-gray-900/80 border border-gray-800">
                <span className="text-[10px] text-gray-500 font-mono-code block">Pending</span>
                <span className="text-base font-gaming font-bold text-amber-400">
                  {pendingRequests.length}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-gray-900/80 border border-gray-800">
                <span className="text-[10px] text-gray-500 font-mono-code block">Approved</span>
                <span className="text-base font-gaming font-bold text-[#00FF66]">
                  {approvedRequests.length}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-gray-900/80 border border-gray-800">
                <span className="text-[10px] text-gray-500 font-mono-code block">Servers</span>
                <span className="text-base font-gaming font-bold text-cyan-400">
                  {servers.length}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-gray-900/80 border border-gray-800">
                <span className="text-[10px] text-gray-500 font-mono-code block">Revenue</span>
                <span className="text-sm font-gaming font-bold text-pink-400 truncate">
                  ৳{totalRevenue}
                </span>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-gray-800 bg-[#0B1015]">
              <button
                onClick={() => setActiveTab('requests')}
                className={`flex-1 py-2.5 text-xs font-gaming font-bold tracking-wide transition-colors ${
                  activeTab === 'requests'
                    ? 'text-[#00FF66] border-b-2 border-[#00FF66] bg-emerald-950/20'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                bKash Requests ({pendingRequests.length})
              </button>
              <button
                onClick={() => setActiveTab('servers')}
                className={`flex-1 py-2.5 text-xs font-gaming font-bold tracking-wide transition-colors ${
                  activeTab === 'servers'
                    ? 'text-[#00FF66] border-b-2 border-[#00FF66] bg-emerald-950/20'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Server Fleet ({servers.length})
              </button>
              <button
                onClick={() => setActiveTab('wireguard')}
                className={`flex-1 py-2.5 text-xs font-gaming font-bold tracking-wide transition-colors ${
                  activeTab === 'wireguard'
                    ? 'text-[#00FF66] border-b-2 border-[#00FF66] bg-emerald-950/20'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                WireGuard Configs
              </button>
            </div>

            {/* Tab Body */}
            <div className="p-4 overflow-y-auto flex-1 space-y-4">
              {/* TAB 1: bKash Requests */}
              {activeTab === 'requests' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-gray-400 font-mono-code">
                    <span>Target bKash Number: 01770110154</span>
                    <span>Fee: 300 BDT</span>
                  </div>

                  {requests.length === 0 ? (
                    <div className="text-center py-8 text-gray-500 text-xs">
                      No requests submitted yet.
                    </div>
                  ) : (
                    requests.map((req) => (
                      <div
                        key={req.id}
                        className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left ${
                          req.status === 'pending'
                            ? 'bg-amber-950/10 border-amber-500/40'
                            : req.status === 'approved'
                            ? 'bg-emerald-950/10 border-emerald-500/30'
                            : 'bg-red-950/10 border-red-500/30'
                        }`}
                      >
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-mono-code font-bold text-sm text-white">
                              {req.trxId}
                            </span>
                            <span className="text-xs px-2 py-0.5 rounded font-mono-code bg-black/60 text-pink-400 border border-pink-500/30">
                              ৳{req.amount}
                            </span>
                            <span
                              className={`text-[10px] uppercase font-mono-code font-bold px-2 py-0.5 rounded ${
                                req.status === 'approved'
                                  ? 'bg-emerald-900/60 text-emerald-300'
                                  : req.status === 'rejected'
                                  ? 'bg-red-900/60 text-red-300'
                                  : 'bg-amber-900/60 text-amber-300 animate-pulse'
                              }`}
                            >
                              {req.status}
                            </span>
                          </div>

                          <div className="text-xs text-gray-400 mt-1 space-x-2">
                            <span>Sender: {req.phoneNumber}</span>
                            <span>•</span>
                            <span>User: {req.userName || req.userEmail}</span>
                            <span>•</span>
                            <span className="text-[11px] text-gray-500">
                              {new Date(req.createdAt).toLocaleTimeString()}
                            </span>
                          </div>

                          {req.adminNote && (
                            <p className="text-[11px] text-gray-400 font-mono-code mt-1 italic">
                              Note: {req.adminNote}
                            </p>
                          )}
                        </div>

                        {req.status === 'pending' && (
                          <div className="flex items-center space-x-2 shrink-0">
                            <button
                              onClick={() => handleApprove(req.id)}
                              className="px-3 py-1.5 rounded-lg bg-[#00FF66] hover:bg-emerald-400 text-black font-gaming font-bold text-xs flex items-center space-x-1 shadow-md shadow-emerald-500/20"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>{t.approve}</span>
                            </button>
                            <button
                              onClick={() => handleReject(req.id)}
                              className="px-3 py-1.5 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/40 font-gaming font-bold text-xs flex items-center space-x-1"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>{t.reject}</span>
                            </button>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* TAB 2: Server Fleet Management */}
              {activeTab === 'servers' && (
                <div className="space-y-4 text-left">
                  {/* Add New Server Form */}
                  <form
                    onSubmit={handleAddServer}
                    className="p-4 rounded-xl bg-gray-900/70 border border-gray-800 space-y-3"
                  >
                    <span className="font-gaming font-bold text-sm text-emerald-400 flex items-center gap-1.5">
                      <Plus className="w-4 h-4" />
                      Add New WireGuard Server Node
                    </span>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="text-gray-400 block mb-1">Server Name</label>
                        <input
                          type="text"
                          placeholder="e.g. Bangladesh - BDIX Gaming 02"
                          value={newServerName}
                          onChange={(e) => setNewServerName(e.target.value)}
                          className="w-full px-3 py-1.5 bg-black border border-gray-700 rounded-lg text-white"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-gray-400 block mb-1">Endpoint (IP:Port)</label>
                        <input
                          type="text"
                          placeholder="e.g. 103.205.180.12:51820"
                          value={newServerEndpoint}
                          onChange={(e) => setNewServerEndpoint(e.target.value)}
                          className="w-full px-3 py-1.5 bg-black border border-gray-700 rounded-lg text-white font-mono-code"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-gray-400 block mb-1">Country & Flag</label>
                        <input
                          type="text"
                          placeholder="e.g. 🇧🇩 Bangladesh"
                          value={`${newServerFlag} ${newServerCountry}`}
                          onChange={(e) => {
                            const val = e.target.value;
                            setNewServerFlag(val.slice(0, 2));
                            setNewServerCountry(val.slice(2).trim());
                          }}
                          className="w-full px-3 py-1.5 bg-black border border-gray-700 rounded-lg text-white"
                        />
                      </div>
                      <div>
                        <label className="text-gray-400 block mb-1">Free Fire Game Tag</label>
                        <input
                          type="text"
                          placeholder="e.g. Free Fire BD 15ms"
                          value={newServerGameTag}
                          onChange={(e) => setNewServerGameTag(e.target.value)}
                          className="w-full px-3 py-1.5 bg-black border border-gray-700 rounded-lg text-white"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <label className="flex items-center space-x-2 text-xs text-gray-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={newServerIsVip}
                          onChange={(e) => setNewServerIsVip(e.target.checked)}
                          className="rounded border-gray-700 text-emerald-500 focus:ring-0"
                        />
                        <span>Require VIP Pass (৳300/mo)</span>
                      </label>

                      <button
                        type="submit"
                        className="px-4 py-1.5 rounded-lg bg-[#00FF66] hover:bg-emerald-400 text-black font-gaming font-bold text-xs shadow-md shadow-emerald-500/20"
                      >
                        Deploy Node
                      </button>
                    </div>
                  </form>

                  {/* List Existing Servers */}
                  <div className="space-y-2">
                    <span className="text-xs font-gaming font-bold text-gray-400 uppercase tracking-wide">
                      Active VPN Nodes ({servers.length})
                    </span>
                    {servers.map((srv) => (
                      <div
                        key={srv.id}
                        className="p-3 rounded-xl bg-gray-900/60 border border-gray-800 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center space-x-3">
                          <span className="text-xl">{srv.flag}</span>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-gaming font-bold text-white">{srv.name}</span>
                              {srv.isPremium ? (
                                <span className="text-[9px] px-1.5 rounded bg-amber-500/20 text-amber-300 font-mono-code font-bold">
                                  VIP
                                </span>
                              ) : (
                                <span className="text-[9px] px-1.5 rounded bg-emerald-500/10 text-emerald-400 font-mono-code font-bold">
                                  FREE
                                </span>
                              )}
                            </div>
                            <span className="font-mono-code text-[11px] text-gray-400">
                              {srv.endpoint} • Ping: {srv.ping}ms
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => handleDeleteServer(srv.id)}
                          className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-950/30 rounded-lg transition-colors"
                          title="Delete server"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: WireGuard Config Generator */}
              {activeTab === 'wireguard' && (
                <div className="space-y-3 text-left">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Select Server</label>
                      <select
                        value={selectedServerForWg?.id}
                        onChange={(e) => {
                          const found = servers.find((s) => s.id === e.target.value);
                          if (found) setSelectedServerForWg(found);
                        }}
                        className="px-3 py-1.5 bg-black border border-gray-700 rounded-lg text-xs text-white"
                      >
                        {servers.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.flag} {s.name} ({s.endpoint})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={handleCopyWgConfig}
                        className="px-3 py-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-xs font-gaming font-bold text-gray-200 flex items-center space-x-1"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{copiedWg ? 'Copied!' : 'Copy .conf'}</span>
                      </button>
                      <button
                        onClick={handleDownloadConf}
                        className="px-3 py-1.5 rounded-lg bg-[#00FF66] hover:bg-emerald-400 text-xs font-gaming font-bold text-black flex items-center space-x-1 shadow-sm shadow-emerald-500/20"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download .conf</span>
                      </button>
                    </div>
                  </div>

                  {/* WireGuard Config Code Block */}
                  <div className="p-3 bg-black border border-gray-800 rounded-xl font-mono-code text-[11px] text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed">
                    {currentWgConfig}
                  </div>

                  <p className="text-[11px] text-gray-400">
                    💡 This WireGuard configuration contains the client private key, DNS (1.1.1.1),
                    MTU 1280 (optimized for zero packet loss in Free Fire mobile gaming), and server
                    peer public keys.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
