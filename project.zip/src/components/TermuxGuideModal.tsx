import React, { useState } from 'react';
import { X, Terminal, Copy, Check, Smartphone, Cloud, ArrowRight, ShieldCheck, Download } from 'lucide-react';
import { Language } from '../types/vpn';
import { translations } from '../locales/translations';

interface TermuxGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const TermuxGuideModal: React.FC<TermuxGuideModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [guideTab, setGuideTab] = useState<'termux' | 'github' | 'server'>('termux');
  const t = translations[lang];

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#070B0E] border border-emerald-500/40 rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-emerald-500/30 flex items-center justify-between bg-gradient-to-r from-emerald-950/40 via-[#0B1015] to-[#070B0E]">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40">
              <Smartphone className="w-5 h-5 text-[#00FF66]" />
            </div>
            <div>
              <h2 className="font-gaming font-extrabold text-base text-white tracking-wide">
                {t.apkInstructions}
              </h2>
              <p className="text-[11px] text-emerald-400 font-mono-code">No PC Required • 100% Android Mobile</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex border-b border-gray-800 bg-[#0B1015] text-xs">
          <button
            onClick={() => setGuideTab('termux')}
            className={`flex-1 py-2.5 font-gaming font-bold tracking-wide transition-colors ${
              guideTab === 'termux'
                ? 'text-[#00FF66] border-b-2 border-[#00FF66] bg-emerald-950/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            📱 Termux Direct Build
          </button>
          <button
            onClick={() => setGuideTab('github')}
            className={`flex-1 py-2.5 font-gaming font-bold tracking-wide transition-colors ${
              guideTab === 'github'
                ? 'text-[#00FF66] border-b-2 border-[#00FF66] bg-emerald-950/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            ⚡ 1-Click Cloud APK (Fastest)
          </button>
          <button
            onClick={() => setGuideTab('server')}
            className={`flex-1 py-2.5 font-gaming font-bold tracking-wide transition-colors ${
              guideTab === 'server'
                ? 'text-[#00FF66] border-b-2 border-[#00FF66] bg-emerald-950/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            🌐 VPS Server Setup
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-left text-xs leading-relaxed text-gray-300">
          {/* TAB 1: Direct Termux Build */}
          {guideTab === 'termux' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 text-xs">
                💡 <strong>কম্পিউটার ছাড়া আপনার ফোনেই APK বানানোর নিয়ম:</strong> F-Droid থেকে Termux ইনস্টল করে নিচের ধাপগুলো সম্পন্ন করুন।
              </div>

              {/* Step 1 */}
              <div className="p-3 rounded-xl bg-[#0B1015] border border-gray-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-gaming font-bold text-gray-200">
                    ধাপ ১: Termux প্যাকেজ ও প্রয়োজনীয় টুলস ইনস্টল
                  </span>
                  <button
                    onClick={() =>
                      copyToClipboard(
                        'pkg update && pkg upgrade -y && pkg install -y git nodejs-lts openjdk-17 wget unzip && termux-setup-storage',
                        1
                      )
                    }
                    className="flex items-center space-x-1 px-2 py-1 rounded bg-gray-800 hover:bg-gray-700 text-emerald-400 font-mono-code text-[11px]"
                  >
                    {copiedIndex === 1 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 1 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="p-2 bg-black rounded font-mono-code text-[11px] text-emerald-400 overflow-x-auto whitespace-pre">
                  pkg update && pkg upgrade -y && pkg install -y git nodejs-lts openjdk-17 wget unzip && termux-setup-storage
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-3 rounded-xl bg-[#0B1015] border border-gray-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-gaming font-bold text-gray-200">
                    ধাপ ২: ওয়েব বিল্ড ও Capacitor Sync
                  </span>
                  <button
                    onClick={() => copyToClipboard('npm install && npm run build && npx cap sync android', 2)}
                    className="flex items-center space-x-1 px-2 py-1 rounded bg-gray-800 hover:bg-gray-700 text-emerald-400 font-mono-code text-[11px]"
                  >
                    {copiedIndex === 2 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 2 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="p-2 bg-black rounded font-mono-code text-[11px] text-emerald-400 overflow-x-auto whitespace-pre">
                  npm install && npm run build && npx cap sync android
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3 rounded-xl bg-[#0B1015] border border-gray-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-gaming font-bold text-gray-200">
                    ধাপ ৩: WireGuard APK কম্পাইল করা (Gradle)
                  </span>
                  <button
                    onClick={() => copyToClipboard('cd android && chmod +x gradlew && ./gradlew assembleDebug', 3)}
                    className="flex items-center space-x-1 px-2 py-1 rounded bg-gray-800 hover:bg-gray-700 text-emerald-400 font-mono-code text-[11px]"
                  >
                    {copiedIndex === 3 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 3 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="p-2 bg-black rounded font-mono-code text-[11px] text-emerald-400 overflow-x-auto whitespace-pre">
                  cd android && chmod +x gradlew && ./gradlew assembleDebug
                </div>
                <p className="text-[11px] text-gray-400 font-mono-code">
                  বিল্ড সম্পন্ন হলে APK ফাইলটি তৈরি হবে:
                  <br />
                  <code className="text-emerald-400">android/app/build/outputs/apk/debug/app-debug.apk</code>
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: GitHub Actions Cloud Build */}
          {guideTab === 'github' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-300">
                🚀 <strong>সবচেয়ে দ্রুত ও সহজ পদ্ধতি (৩ মিনিটে রেডি APK):</strong> আপনার ফোনে বেশি র‍্যাম না থাকলে GitHub Actions স্বয়ংক্রিয়ভাবে ক্লাউড সার্ভারে APK তৈরি করে দিবে। ফাইলটি ইতোমধ্যে রেপোজিটরিতে যোগ করা হয়েছে: <code>.github/workflows/build-apk.yml</code>
              </div>

              <div className="p-3 rounded-xl bg-[#0B1015] border border-gray-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-gaming font-bold text-gray-200">
                    Termux থেকে GitHub এ পুশ করুন:
                  </span>
                  <button
                    onClick={() =>
                      copyToClipboard(
                        'git init\ngit add .\ngit commit -m "FF VPN Release"\ngit branch -M main\ngit remote add origin https://github.com/YOUR_USERNAME/ff-vpn.git\ngit push -u origin main',
                        4
                      )
                    }
                    className="flex items-center space-x-1 px-2 py-1 rounded bg-gray-800 hover:bg-gray-700 text-emerald-400 font-mono-code text-[11px]"
                  >
                    {copiedIndex === 4 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 4 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="p-2 bg-black rounded font-mono-code text-[11px] text-emerald-400 overflow-x-auto whitespace-pre">
{`git init
git add .
git commit -m "FF VPN Release"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ff-vpn.git
git push -u origin main`}
                </div>
                <p className="text-[11px] text-gray-400">
                  পুশ করার পর আপনার ফোনের ব্রাউজার দিয়ে GitHub Repository → "Actions" ট্যাবে গিয়ে ২ মিনিট পর সরাসরি <strong>FF-VPN-Debug-APK</strong> ডাউনলোড করে ইনস্টল করুন!
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: VPS Server Setup */}
          {guideTab === 'server' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-300">
                🌐 <strong>আসল WireGuard ভিপিএন সার্ভার চালু করার নিয়ম:</strong> যেকোনো লিনাক্স VPS (Ubuntu 22.04 / 24.04 বা BDIX সার্ভার)-এ মাত্র ১টি কমান্ড চালিয়ে নিজের সার্ভার চালু করুন।
              </div>

              <div className="p-3 rounded-xl bg-[#0B1015] border border-gray-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-gaming font-bold text-gray-200">
                    ১-ক্লিক WireGuard ইনস্টলার স্ক্রিপ্ট:
                  </span>
                  <button
                    onClick={() =>
                      copyToClipboard(
                        'wget https://git.io/wireguard -O wireguard-install.sh && bash wireguard-install.sh',
                        5
                      )
                    }
                    className="flex items-center space-x-1 px-2 py-1 rounded bg-gray-800 hover:bg-gray-700 text-emerald-400 font-mono-code text-[11px]"
                  >
                    {copiedIndex === 5 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 5 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="p-2 bg-black rounded font-mono-code text-[11px] text-emerald-400 overflow-x-auto whitespace-pre">
                  wget https://git.io/wireguard -O wireguard-install.sh && bash wireguard-install.sh
                </div>
              </div>

              <div className="p-3 rounded-xl bg-gray-900 border border-gray-800 text-[11px] text-gray-300 space-y-1">
                <p>• স্ক্রিপ্ট চালানো হলে পোর্ট <strong>51820</strong> সিলেক্ট করুন।</p>
                <p>• DNS হিসেবে <strong>1.1.1.1</strong> সিলেক্ট করুন (গেমিংয়ের জন্য সবচেয়ে দ্রুত)।</p>
                <p>• এরপর অ্যাপের অ্যাডমিন প্যানেলে গিয়ে সার্ভারের আইপি ও পাবলিক কি যুক্ত করে দিন।</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
