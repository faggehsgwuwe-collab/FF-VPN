import React from 'react';
import { Shield, Zap, Crown, Terminal, Settings } from 'lucide-react';
import { Language, UserProfile } from '../types/vpn';
import { translations } from '../locales/translations';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  user: UserProfile;
  onOpenPremium: () => void;
  onOpenAdmin: () => void;
  onOpenTermuxGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  user,
  onOpenPremium,
  onOpenAdmin,
  onOpenTermuxGuide,
}) => {
  const t = translations[lang];

  return (
    <header className="w-full px-4 pt-3 pb-2 flex items-center justify-between border-b border-gray-800/80 bg-[#05080A]/90 backdrop-blur-md sticky top-0 z-20">
      {/* Brand & Logo */}
      <div className="flex items-center space-x-2.5">
        <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 via-black to-emerald-950/60 border border-emerald-500/40 neon-border-green">
          <Shield className="w-5 h-5 text-[#00FF66]" />
          <Zap className="w-3 h-3 text-[#00F0FF] absolute -bottom-0.5 -right-0.5" />
        </div>
        <div>
          <div className="flex items-center space-x-1.5">
            <span className="font-gaming font-extrabold tracking-wider text-lg text-white">
              FF <span className="text-[#00FF66]">VPN</span>
            </span>
            <span className="text-[10px] uppercase font-mono-code px-1.5 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 font-bold">
              WG PRO
            </span>
          </div>
          <p className="text-[10px] text-gray-400 font-medium">Free Fire Low-Ping Engine</p>
        </div>
      </div>

      {/* Action Badges */}
      <div className="flex items-center space-x-2">
        {/* VIP Status or Upgrade Button */}
        {user.isPremium ? (
          <button
            onClick={onOpenPremium}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-500/20 to-yellow-500/10 border border-amber-500/50 text-amber-300 text-xs font-gaming font-bold shadow-sm shadow-amber-500/20"
          >
            <Crown className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>VIP ACTIVE</span>
          </button>
        ) : (
          <button
            onClick={onOpenPremium}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-gaming font-bold transition-all"
          >
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.upgradeToPro}</span>
          </button>
        )}

        {/* Termux & APK Guide Button */}
        <button
          onClick={onOpenTermuxGuide}
          title={t.termuxGuide}
          className="p-1.5 rounded-lg bg-gray-900/80 hover:bg-gray-800 border border-gray-700/80 text-gray-300 hover:text-[#00FF66] transition-colors"
        >
          <Terminal className="w-4 h-4" />
        </button>

        {/* Admin Access Button */}
        <button
          onClick={onOpenAdmin}
          title={t.adminPanel}
          className="p-1.5 rounded-lg bg-gray-900/80 hover:bg-gray-800 border border-gray-700/80 text-gray-300 hover:text-[#00FF66] transition-colors"
        >
          <Settings className="w-4 h-4" />
        </button>

        {/* Language Switcher */}
        <button
          onClick={onToggleLang}
          className="px-2 py-1 rounded-lg bg-gray-900 border border-gray-800 hover:border-emerald-500/40 text-[11px] font-bold font-mono-code text-gray-200 transition-colors"
        >
          {lang === 'bn' ? 'বাংলা' : 'EN'}
        </button>
      </div>
    </header>
  );
};
