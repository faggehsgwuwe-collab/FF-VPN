import React from 'react';
import { ArrowDown, ArrowUp, Activity, Gauge, Globe, Shield } from 'lucide-react';
import { ConnectionState, Language, TrafficStats, VpnServer } from '../types/vpn';
import { translations } from '../locales/translations';

interface StatsDashboardProps {
  stats: TrafficStats;
  state: ConnectionState;
  activeServer: VpnServer;
  lang: Language;
}

export const StatsDashboard: React.FC<StatsDashboardProps> = ({
  stats,
  state,
  activeServer,
  lang,
}) => {
  const t = translations[lang];
  const isConnected = state === 'CONNECTED';

  const formatSpeed = (bytesPerSec: number) => {
    if (!isConnected || bytesPerSec === 0) return '0 KB/s';
    if (bytesPerSec >= 1048576) {
      return `${(bytesPerSec / 1048576).toFixed(1)} MB/s`;
    }
    return `${Math.round(bytesPerSec / 1024)} KB/s`;
  };

  const formatTotalData = (bytes: number) => {
    if (!isConnected || bytes === 0) return '0 MB';
    if (bytes >= 1073741824) {
      return `${(bytes / 1073741824).toFixed(2)} GB`;
    }
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  const pingColor =
    stats.latencyMs < 35
      ? 'text-[#00FF66] border-emerald-500/40 bg-emerald-950/40'
      : stats.latencyMs < 75
      ? 'text-cyan-400 border-cyan-500/40 bg-cyan-950/40'
      : 'text-amber-400 border-amber-500/40 bg-amber-950/40';

  return (
    <div className="w-full px-4 mb-4">
      {/* Grid of Telemetry Cards */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Latency / Ping Card */}
        <div className="bg-[#0B1015] border border-gray-800/90 rounded-xl p-3 relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[11px] font-gaming font-semibold tracking-wide uppercase flex items-center gap-1">
              <Gauge className="w-3.5 h-3.5 text-emerald-400" />
              {t.latency}
            </span>
            <span className="text-[10px] font-mono-code text-gray-500">ICMP</span>
          </div>

          <div className="flex items-baseline space-x-1.5 my-1">
            <span className={`text-2xl font-extrabold font-gaming ${isConnected ? 'text-[#00FF66]' : 'text-gray-500'}`}>
              {isConnected ? stats.latencyMs : '--'}
            </span>
            <span className="text-xs text-gray-400 font-mono-code">ms</span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-gray-800/60">
            <span className="text-[10px] text-gray-400 font-mono-code">Packet Loss</span>
            <span className="text-[10px] font-bold font-mono-code text-emerald-400">
              {isConnected ? `${stats.packetLoss}%` : '0%'}
            </span>
          </div>
        </div>

        {/* Current Virtual IP / Server Node */}
        <div className="bg-[#0B1015] border border-gray-800/90 rounded-xl p-3 relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[11px] font-gaming font-semibold tracking-wide uppercase flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              {t.currentIp}
            </span>
            <span className="text-[10px] font-mono-code text-cyan-400">WG0</span>
          </div>

          <div className="my-1">
            <span className="text-xs font-mono-code font-bold text-gray-200 block truncate">
              {isConnected ? stats.ipAddress : 'Disconnected'}
            </span>
            <span className="text-[10px] text-gray-500 truncate block">
              {activeServer.city}, {activeServer.countryCode}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-gray-800/60">
            <span className="text-[10px] text-gray-400 font-mono-code">MTU</span>
            <span className="text-[10px] font-bold font-mono-code text-cyan-400">1280 (Anti-Jitter)</span>
          </div>
        </div>

        {/* Live Download Speed */}
        <div className="bg-[#0B1015] border border-gray-800/90 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[11px] font-gaming font-semibold tracking-wide uppercase flex items-center gap-1">
              <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
              {t.download}
            </span>
            <span className="text-[10px] font-mono-code text-gray-500">Down</span>
          </div>

          <div className="my-1">
            <span className="text-lg font-bold font-gaming text-emerald-400">
              {formatSpeed(stats.downloadSpeed)}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-gray-800/60">
            <span className="text-[10px] text-gray-400 font-mono-code">Total</span>
            <span className="text-[10px] font-mono-code text-gray-300">
              {formatTotalData(stats.bytesIn)}
            </span>
          </div>
        </div>

        {/* Live Upload Speed */}
        <div className="bg-[#0B1015] border border-gray-800/90 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[11px] font-gaming font-semibold tracking-wide uppercase flex items-center gap-1">
              <ArrowUp className="w-3.5 h-3.5 text-cyan-400" />
              {t.upload}
            </span>
            <span className="text-[10px] font-mono-code text-gray-500">Up</span>
          </div>

          <div className="my-1">
            <span className="text-lg font-bold font-gaming text-cyan-400">
              {formatSpeed(stats.uploadSpeed)}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-gray-800/60">
            <span className="text-[10px] text-gray-400 font-mono-code">Total</span>
            <span className="text-[10px] font-mono-code text-gray-300">
              {formatTotalData(stats.bytesOut)}
            </span>
          </div>
        </div>
      </div>

      {/* Gaming Low-Ping Tag Banner */}
      <div className="mt-2.5 px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-950/40 via-[#0B1015] to-cyan-950/30 border border-emerald-500/20 flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-pulse" />
          <span className="font-gaming font-bold text-gray-200">
            {activeServer.gameTag}
          </span>
        </div>
        <span className="text-[11px] font-mono-code text-emerald-400/90 font-medium">
          ChaCha20 • WireGuard
        </span>
      </div>
    </div>
  );
};
