import React, { useState } from 'react';
import { X, Search, Crown, Signal, Check, Lock, Zap, Shield } from 'lucide-react';
import { Language, UserProfile, VpnServer } from '../types/vpn';
import { translations } from '../locales/translations';

interface ServerModalProps {
  isOpen: boolean;
  onClose: () => void;
  servers: VpnServer[];
  activeServer: VpnServer;
  onSelectServer: (server: VpnServer) => void;
  user: UserProfile;
  onOpenPremium: () => void;
  lang: Language;
}

export const ServerModal: React.FC<ServerModalProps> = ({
  isOpen,
  onClose,
  servers,
  activeServer,
  onSelectServer,
  user,
  onOpenPremium,
  lang,
}) => {
  const [filter, setFilter] = useState<'all' | 'gaming' | 'free' | 'vip'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const t = translations[lang];

  if (!isOpen) return null;

  const filteredServers = servers.filter((server) => {
    const matchesSearch =
      server.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      server.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      server.city.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filter === 'gaming') return server.ping <= 45;
    if (filter === 'free') return !server.isPremium;
    if (filter === 'vip') return server.isPremium;
    return true;
  });

  const handleSelect = (server: VpnServer) => {
    if (server.isPremium && !user.isPremium) {
      onClose();
      onOpenPremium();
      return;
    }
    onSelectServer(server);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-[#070B0E] border border-gray-800 rounded-t-2xl sm:rounded-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-gray-800 flex items-center justify-between bg-[#0B1015]">
          <div className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-[#00FF66]" />
            <h2 className="font-gaming font-bold text-base text-white tracking-wide">
              {t.selectServer}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Tabs */}
        <div className="p-4 border-b border-gray-800/80 bg-[#070B0E] space-y-3">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-gray-500 absolute left-3 top-3" />
            <input
              type="text"
              placeholder={lang === 'bn' ? 'সার্ভার বা দেশ খুঁজুন...' : 'Search country, city, or node...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-gray-900 border border-gray-800 rounded-xl text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-emerald-500/60"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1">
            {[
              { id: 'all', label: t.allServers },
              { id: 'gaming', label: '🔥 ' + t.recommended },
              { id: 'free', label: t.freeServers },
              { id: 'vip', label: '👑 ' + t.premiumServers },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-gaming font-semibold whitespace-nowrap transition-all ${
                  filter === tab.id
                    ? 'bg-[#00FF66] text-black shadow-md shadow-emerald-500/30'
                    : 'bg-gray-900 text-gray-400 hover:text-white hover:bg-gray-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Server List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1">
          {filteredServers.length === 0 ? (
            <div className="text-center py-10 text-gray-500 text-sm">
              {lang === 'bn' ? 'কোনো সার্ভার খুঁজে পাওয়া যায়নি' : 'No servers found matching criteria'}
            </div>
          ) : (
            filteredServers.map((server) => {
              const isSelected = activeServer.id === server.id;
              const isLocked = server.isPremium && !user.isPremium;

              return (
                <div
                  key={server.id}
                  onClick={() => handleSelect(server)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all duration-200 flex items-center justify-between relative ${
                    isSelected
                      ? 'bg-emerald-950/30 border-[#00FF66] shadow-sm shadow-emerald-500/20'
                      : isLocked
                      ? 'bg-[#0B1015]/60 border-gray-800/60 opacity-80 hover:opacity-100 hover:border-amber-500/40'
                      : 'bg-[#0B1015] border-gray-800/90 hover:border-emerald-500/40 hover:bg-[#111822]'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{server.flag}</span>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-gaming font-bold text-sm text-gray-100">
                          {server.name}
                        </span>
                        {server.isPremium && (
                          <span className="text-[10px] font-mono-code px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                            VIP
                          </span>
                        )}
                      </div>
                      <div className="flex items-center space-x-2 text-xs text-gray-400 mt-0.5">
                        <span className="text-emerald-400 font-mono-code font-semibold flex items-center gap-1">
                          <Signal className="w-3 h-3" />
                          {server.ping} ms
                        </span>
                        <span>•</span>
                        <span className="text-gray-400 text-[11px]">{server.gameTag}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {/* Load indicator */}
                    <div className="hidden sm:flex flex-col items-end">
                      <span className="text-[10px] text-gray-500 font-mono-code">Load</span>
                      <div className="w-12 h-1.5 bg-gray-800 rounded-full overflow-hidden mt-0.5">
                        <div
                          className={`h-full ${
                            server.load < 50
                              ? 'bg-emerald-400'
                              : server.load < 80
                              ? 'bg-amber-400'
                              : 'bg-red-400'
                          }`}
                          style={{ width: `${server.load}%` }}
                        />
                      </div>
                    </div>

                    {/* Status action icon */}
                    {isSelected ? (
                      <div className="w-7 h-7 rounded-full bg-[#00FF66] text-black flex items-center justify-center font-bold">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </div>
                    ) : isLocked ? (
                      <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center justify-center">
                        <Lock className="w-3.5 h-3.5" />
                      </div>
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-gray-800 text-gray-400 flex items-center justify-center group-hover:bg-gray-700">
                        <Zap className="w-3.5 h-3.5 text-emerald-400" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Prompt */}
        {!user.isPremium && (
          <div className="p-3 bg-gradient-to-r from-amber-950/40 via-black to-yellow-950/30 border-t border-amber-500/20 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2 text-amber-200">
              <Crown className="w-4 h-4 text-amber-400 animate-bounce" />
              <span>{t.vipLockedNotice}</span>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenPremium();
              }}
              className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-gaming font-bold text-xs"
            >
              {t.upgradeToPro}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
