import { registerPlugin, Capacitor } from '@capacitor/core';
import { TrafficStats, WireGuardConfig } from '../types/vpn';

export interface WireGuardVpnPluginInterface {
  prepareVpn(): Promise<{ prepared: boolean; message?: string }>;
  connect(options: {
    tunnelName: string;
    configText: string;
    serverEndpoint: string;
  }): Promise<{ success: boolean; state: string }>;
  disconnect(): Promise<{ success: boolean; state: string }>;
  getStatus(): Promise<{
    state: 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'DISCONNECTING' | 'ERROR';
    traffic: TrafficStats;
  }>;
  pingServer(options: { host: string; port: number }): Promise<{ latencyMs: number }>;
}

// Register native Capacitor plugin
export const WireGuardNative = registerPlugin<WireGuardVpnPluginInterface>('WireGuardVpn', {
  web: {
    async prepareVpn() {
      // In web browser preview mode
      return {
        prepared: true,
        message: 'Web Preview: Android VpnService is active when compiled as APK with Capacitor.',
      };
    },
    async connect(options: { tunnelName: string; configText: string; serverEndpoint: string }) {
      console.log('[WireGuard Web Mock] Connecting with config:\n', options.configText);
      return { success: true, state: 'CONNECTED' };
    },
    async disconnect() {
      console.log('[WireGuard Web Mock] Disconnected');
      return { success: true, state: 'DISCONNECTED' };
    },
    async getStatus() {
      return {
        state: 'CONNECTED' as const,
        traffic: {
          bytesIn: 1048576,
          bytesOut: 524288,
          downloadSpeed: 1850000,
          uploadSpeed: 640000,
          durationSeconds: 120,
          latencyMs: 24,
          packetLoss: 0,
          ipAddress: '10.8.2.145',
        },
      };
    },
    async pingServer(options: { host: string; port: number }) {
      const start = performance.now();
      try {
        await fetch(`https://dns.google/resolve?name=${options.host}`, { method: 'HEAD', mode: 'no-cors' });
        return { latencyMs: Math.round(performance.now() - start) };
      } catch {
        return { latencyMs: Math.floor(Math.random() * 20) + 20 };
      }
    },
  },
});

export const isNativeAndroid = (): boolean => {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
};
