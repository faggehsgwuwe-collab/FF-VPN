import { VpnServer, WireGuardConfig } from '../types/vpn';

/**
 * Generate a random 32-byte Base64 key for WireGuard client private/public key.
 */
export function generateWireGuardKey(): string {
  const array = new Uint8Array(32);
  if (typeof window !== 'undefined' && window.crypto) {
    window.crypto.getRandomValues(array);
  } else {
    for (let i = 0; i < 32; i++) {
      array[i] = Math.floor(Math.random() * 256);
    }
  }
  // Clamp keys for curve25519 if private key
  array[0] &= 248;
  array[31] &= 127;
  array[31] |= 64;

  let binary = '';
  for (let i = 0; i < array.byteLength; i++) {
    binary += String.fromCharCode(array[i]);
  }
  return btoa(binary);
}

/**
 * Build WireGuard configuration object for a specific server and client.
 */
export function buildWireGuardConfig(
  server: VpnServer,
  clientPrivateKey?: string,
  clientIp?: string
): WireGuardConfig {
  const privateKey = clientPrivateKey || generateWireGuardKey();
  const address = clientIp || `10.8.${server.isPremium ? '2' : '1'}.${Math.floor(Math.random() * 240) + 10}/24`;

  return {
    privateKey,
    clientAddress: address,
    dns: server.dns || '1.1.1.1, 8.8.8.8',
    mtu: 1280, // 1280 MTU ensures zero packet fragmentation in mobile networks (Free Fire / PUBG mobile low jitter)
    serverPublicKey: server.serverPublicKey,
    endpoint: server.endpoint,
    allowedIPs: server.allowedIPs || '0.0.0.0/0, ::/0',
    persistentKeepalive: 25,
  };
}

/**
 * Format WireGuard config object into standard .conf file string.
 */
export function formatWireGuardConfigFile(config: WireGuardConfig): string {
  return `[Interface]
# FF VPN Client Configuration
PrivateKey = ${config.privateKey}
Address = ${config.clientAddress}
DNS = ${config.dns}
MTU = ${config.mtu}

[Peer]
# FF VPN Server Node
PublicKey = ${config.serverPublicKey}
Endpoint = ${config.endpoint}
AllowedIPs = ${config.allowedIPs}
PersistentKeepalive = ${config.persistentKeepalive}
`;
}
