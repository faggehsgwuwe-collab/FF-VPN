import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { DEFAULT_SERVERS } from '../data/defaultServers';
import { PremiumRequest, UserProfile, VpnServer } from '../types/vpn';

// Environment variables or fallback config
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyDemoDummyKeyForFFVpnPreviewMode123',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'ff-vpn-app.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'ff-vpn-app',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'ff-vpn-app.appspot.com',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '592058916642',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:592058916642:web:ffvpn1234567890',
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);

// Local persistence storage keys
const STORAGE_SERVERS_KEY = 'ff_vpn_servers_v1';
const STORAGE_REQUESTS_KEY = 'ff_vpn_premium_requests_v1';
const STORAGE_USER_KEY = 'ff_vpn_current_user_v1';

// Seed initial default servers if not present
export function initServersStorage(): VpnServer[] {
  if (typeof window === 'undefined') return DEFAULT_SERVERS;
  const stored = localStorage.getItem(STORAGE_SERVERS_KEY);
  if (!stored) {
    localStorage.setItem(STORAGE_SERVERS_KEY, JSON.stringify(DEFAULT_SERVERS));
    return DEFAULT_SERVERS;
  }
  try {
    return JSON.parse(stored);
  } catch {
    return DEFAULT_SERVERS;
  }
}

export function saveServersStorage(servers: VpnServer[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_SERVERS_KEY, JSON.stringify(servers));
  }
}

// User Profile Service
export function getOrCreateUserProfile(): UserProfile {
  if (typeof window === 'undefined') {
    return {
      id: 'demo-user-1',
      email: 'gamer@ffvpn.app',
      displayName: 'FF Gaming Pro',
      isPremium: false,
      role: 'user',
    };
  }

  const stored = localStorage.getItem(STORAGE_USER_KEY);
  if (stored) {
    try {
      const user = JSON.parse(stored);
      // Check if premium has expired
      if (user.isPremium && user.premiumExpiry && Date.now() > user.premiumExpiry) {
        user.isPremium = false;
        localStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
      }
      return user;
    } catch {
      // fallback
    }
  }

  const defaultUser: UserProfile = {
    id: 'user_' + Math.random().toString(36).substring(2, 9),
    email: 'user_' + Math.floor(Math.random() * 9000 + 1000) + '@ffvpn.app',
    displayName: 'Gamer_' + Math.floor(Math.random() * 899 + 100),
    isPremium: false,
    role: 'user',
  };
  localStorage.setItem(STORAGE_USER_KEY, JSON.stringify(defaultUser));
  return defaultUser;
}

export function saveUserProfile(user: UserProfile): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
  }
}

// Premium Requests Service
export function getStoredPremiumRequests(): PremiumRequest[] {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(STORAGE_REQUESTS_KEY);
  if (!stored) {
    // Seed initial demo requests so admin panel has sample items to inspect immediately
    const seedRequests: PremiumRequest[] = [
      {
        id: 'req_seed_101',
        userId: 'user_tamim',
        userEmail: 'tamim.gamer@gmail.com',
        userName: 'Tamim Hasan',
        phoneNumber: '01819283746',
        trxId: 'BKA89102X9',
        amount: 300,
        method: 'bKash',
        status: 'pending',
        createdAt: Date.now() - 1000 * 60 * 18, // 18 mins ago
        updatedAt: Date.now() - 1000 * 60 * 18,
      },
      {
        id: 'req_seed_102',
        userId: 'user_sabbir',
        userEmail: 'sabbir.ff@gmail.com',
        userName: 'Sabbir Ahmed',
        phoneNumber: '01912345678',
        trxId: 'BKA76431Y2',
        amount: 300,
        method: 'bKash',
        status: 'approved',
        createdAt: Date.now() - 1000 * 60 * 60 * 4,
        updatedAt: Date.now() - 1000 * 60 * 60 * 3,
        adminNote: 'bKash verified via 01770110154 statement',
      },
    ];
    localStorage.setItem(STORAGE_REQUESTS_KEY, JSON.stringify(seedRequests));
    return seedRequests;
  }
  try {
    return JSON.parse(stored);
  } catch {
    return [];
  }
}

export function submitPremiumRequest(params: {
  userId: string;
  userEmail: string;
  userName: string;
  phoneNumber: string;
  trxId: string;
}): PremiumRequest {
  const requests = getStoredPremiumRequests();
  const newRequest: PremiumRequest = {
    id: 'req_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6),
    userId: params.userId,
    userEmail: params.userEmail,
    userName: params.userName,
    phoneNumber: params.phoneNumber.trim(),
    trxId: params.trxId.trim().toUpperCase(),
    amount: 300,
    method: 'bKash',
    status: 'pending',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  requests.unshift(newRequest);
  localStorage.setItem(STORAGE_REQUESTS_KEY, JSON.stringify(requests));
  return newRequest;
}

export function updatePremiumRequestStatus(
  requestId: string,
  status: 'approved' | 'rejected',
  adminNote?: string,
  daysValid: number = 30
): boolean {
  const requests = getStoredPremiumRequests();
  const index = requests.findIndex((r) => r.id === requestId);
  if (index === -1) return false;

  requests[index].status = status;
  requests[index].updatedAt = Date.now();
  if (adminNote) requests[index].adminNote = adminNote;
  localStorage.setItem(STORAGE_REQUESTS_KEY, JSON.stringify(requests));

  // If approved, update user's premium status
  const currentUser = getOrCreateUserProfile();
  if (requests[index].userId === currentUser.id) {
    if (status === 'approved') {
      currentUser.isPremium = true;
      currentUser.premiumExpiry = Date.now() + daysValid * 24 * 60 * 60 * 1000;
    } else if (status === 'rejected') {
      currentUser.isPremium = false;
    }
    saveUserProfile(currentUser);
  }

  return true;
}
