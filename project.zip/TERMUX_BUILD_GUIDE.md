# 📱 FF VPN - Termux ও Android মোবাইল দিয়ে APK বিল্ড করার সম্পূর্ণ গাইড
### (Termux & Mobile Phone APK Build Guide - Bengali + English)

এই প্রজেক্টটি বিশেষভাবে এমনভাবে তৈরি করা হয়েছে যাতে কম্পিউটার (PC) ছাড়া শুধুমাত্র একটি **Android ফোন এবং Termux অ্যাপ** ব্যবহার করেই আপনি সম্পূর্ণ আসল WireGuard VPN Android APK বিল্ড ও ইনস্টল করতে পারেন।

---

## 🚀 পদ্ধতি ১: Termux দিয়ে সরাসরি ফোনে APK বিল্ড করার নিয়ম (Method 1: Direct Build in Termux)

### ধাপ ১: Termux প্রস্তুত করুন
Google Play Store এর Termux পুরানো। তাই [F-Droid](https://f-droid.org/en/packages/com.termux/) থেকে লেটেস্ট Termux ইনস্টল করুন। এরপর Termux ওপেন করে নিচের কমান্ডগুলো দিন:

```bash
# প্যাকেজ আপডেট ও স্টোরেজ পারমিশন
pkg update && pkg upgrade -y
termux-setup-storage

# প্রয়োজনীয় টুলস ইনস্টল করুন
pkg install -y git nodejs-lts openjdk-17 wget unzip
```

### ধাপ ২: প্রজেক্ট কোড নামান বা আনজিপ করুন
যদি গিট রেপো থাকে:
```bash
git clone https://github.com/your-username/ff-vpn-app.git
cd ff-vpn-app
```
অথবা এই অ্যাপ থেকে জিপ ফাইল বা সোর্স ফাইল ডাউনলোড করে:
```bash
cd ~/storage/shared/Download/ff-vpn-app
```

### ধাপ ৩: ডিপেন্ডেন্সি ইনস্টল ও ওয়েব বিল্ড
```bash
npm install
npm run build
```
এটি `dist/` ফোল্ডারে অপ্টিমাইজড ওয়েব কোড তৈরি করবে।

### ধাপ ৪: Capacitor অ্যান্ড্রয়েড সিঙ্ক
```bash
npx cap sync android
```

### ধাপ ৫: Termux এ Android SDK এবং Gradle দিয়ে APK বিল্ড
Termux এ অ্যান্ড্রয়েড কমান্ড লাইন টুলস দিয়ে সরাসরি APK তৈরি করতে:
```bash
# Android SDK কমান্ড লাইন টুল ডাউনলোড (যদি আগে না থাকে)
mkdir -p ~/android-sdk/cmdline-tools
cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip -d latest
mv latest/cmdline-tools/* latest/ 2>/dev/null || true

# Environment variables সেট করুন:
export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

# প্রজেক্ট ফোল্ডারে ফিরে যান
cd /path/to/ff-vpn-app/android

# Gradle wrapper দিয়ে APK কম্পাইল করুন
chmod +x gradlew
./gradlew assembleDebug
```
বিল্ড শেষ হলে আপনার APK টি তৈরি হবে:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## ⚡ পদ্ধতি ২: GitHub Actions দিয়ে ফোন থেকে ১-ক্লিকে ফ্রি ক্লাউড APK বিল্ড (সবচেয়ে সহজ ও ১০০% রিকমেন্ডেড)

যেহেতু ফোনে বিশাল Android SDK এবং WireGuard NDK কম্পাইল করতে অনেক র‍্যাম (RAM) ও স্টোরেজ লাগে, তাই ফোনের Termux দিয়ে মাত্র ৩টি কমান্ডে GitHub Actions এর মাধ্যমে অফিসিয়াল রিলিজ APK তৈরি করার স্বয়ংক্রিয় ফাইল প্রজেক্টে যুক্ত করা হয়েছে (`.github/workflows/build-apk.yml`):

1. আপনার ফোন থেকে GitHub.com এ একটি ফ্রী একাউন্ট খুলে একটি নতুন Repository বানান।
2. Termux এ কোড পুশ করুন:
   ```bash
   git init
   git add .
   git commit -m "FF VPN Initial Release"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/ff-vpn.git
   git push -u origin main
   ```
3. সাথে সাথে GitHub Actions ক্লাউড সার্ভারে মাত্র ৩ মিনিটে সম্পূর্ণ আসল Signed APK তৈরি করে দেবে! আপনি ফোনের ব্রাউজার দিয়ে GitHub Repository -> "Actions" -> Download APK চাপলেই ফোনে সরাসরি APK ডাউনলোড ও ইনস্টল হয়ে যাবে!

---

## 🛡️ আসল WireGuard VpnService পারমিশন কীভাবে কাজ করে?
অ্যাপ ইনস্টল করার পর প্রথমবার **"TAP TO CONNECT"** চাপলে Android সিস্টেমের আসল সিকিউরিটি ডায়ালগ আসবে:
> *"FF VPN wants to set up a VPN connection that allows it to monitor network traffic. Only accept if you trust the source."*

- **OK** চাপলে আপনার ফোনে আসল WireGuard টানেল সক্রিয় হবে।
- স্ট্যাটাস বারে চাবির আইকন (VPN Key Icon) দেখা যাবে।
- নোটিফিকেশন বারে লাইভ পিং এবং ডেটা ট্রাফিক স্পিডোমিটার চলতে থাকবে।
