package com.example

import com.example.data.ServerDataSource
import com.example.vpn.VpnRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun verifyTenDefaultServersLoaded() {
    val servers = ServerDataSource.defaultServers
    assertEquals(10, servers.size)

    val countries = servers.map { it.country }
    assertTrue(countries.contains("Bangladesh"))
    assertTrue(countries.contains("Singapore"))
    assertTrue(countries.contains("India"))
    assertTrue(countries.contains("United States"))
    assertTrue(countries.contains("Brazil"))
    assertTrue(countries.contains("United Arab Emirates"))
    assertTrue(countries.contains("Japan"))
    assertTrue(countries.contains("Germany"))
    assertTrue(countries.contains("Netherlands"))
    assertTrue(countries.contains("United Kingdom"))
  }

  @Test
  fun testWireGuardConfigGeneration() {
    val dhakaServer = ServerDataSource.defaultServers.first { it.id == "bd-dhaka-01" }
    val wgConfig = dhakaServer.generateWireGuardConfig(clientPrivateKey = "testKey123=")

    assertTrue(wgConfig.contains("[Interface]"))
    assertTrue(wgConfig.contains("PrivateKey = testKey123="))
    assertTrue(wgConfig.contains("MTU = 1420"))
    assertTrue(wgConfig.contains("[Peer]"))
    assertTrue(wgConfig.contains("Endpoint = 103.145.118.24:51820"))
  }

  @Test
  fun testPremiumApprovalWorkflow() {
    val submitted = VpnRepository.submitPremiumRequest("BL98TEST123")
    assertTrue(submitted)

    val latestReq = VpnRepository.premiumRequests.value.first()
    assertEquals("BL98TEST123", latestReq.transactionId)

    VpnRepository.approvePremiumRequest(latestReq.id)
    val approvedReq = VpnRepository.premiumRequests.value.first { it.id == latestReq.id }
    assertEquals("APPROVED", approvedReq.status)
    assertTrue(VpnRepository.userAccount.value.isPremium)
  }
}
