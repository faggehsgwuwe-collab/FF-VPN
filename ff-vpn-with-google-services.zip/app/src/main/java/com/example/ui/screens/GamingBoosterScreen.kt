package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionState
import com.example.ui.components.PingBadge
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingCardElevated
import com.example.ui.theme.GamingDarkBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.GamingOrange
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.VpnRepository

@Composable
fun GamingBoosterScreen(
  onNavigateToServers: () -> Unit,
  modifier: Modifier = Modifier
) {
  val currentServer by VpnRepository.currentServer.collectAsState()
  val connectionState by VpnRepository.connectionState.collectAsState()
  val trafficStats by VpnRepository.trafficStats.collectAsState()
  val gamingMode by VpnRepository.gamingModeEnabled.collectAsState()
  val selectedDns by VpnRepository.selectedDns.collectAsState()
  val language by VpnRepository.language.collectAsState()
  val serverList by VpnRepository.serverList.collectAsState()

  val gamingServers = serverList.filter { it.isGamingOptimized }

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = if (language == "bn") "ফ্রি ফায়ার গেমিং বুস্টার" else "Free Fire Gaming Booster",
          fontSize = 20.sp,
          fontWeight = FontWeight.Black,
          color = TextPrimary
        )
        Text(
          text = if (language == "bn") "লো পিং ও নেটওয়ার্ক রাউটিং অপটিমাইজার" else "Low ping & network routing optimizer",
          fontSize = 12.sp,
          color = TextMuted
        )
      }
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(GamingOrange.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.SportsEsports,
          contentDescription = "Esports",
          tint = GamingOrange,
          modifier = Modifier.size(20.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Real-time Gaming Telemetry Panel
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardElevated),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = Brush.linearGradient(listOf(GamingOrange, NeonGreen.copy(alpha = 0.4f)))
      )
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Speed,
              contentDescription = "Ping",
              tint = NeonGreen,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (language == "bn") "লাইভ গেমিং পিং" else "Live Gaming Ping",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }

          val currentPing = if (connectionState == ConnectionState.CONNECTED) {
            trafficStats.currentPingMs.coerceAtLeast(10)
          } else {
            currentServer.pingMs
          }
          PingBadge(pingMs = currentPing)
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Telemetry Grid
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Jitter
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(GamingDarkBg)
              .padding(10.dp)
          ) {
            Column {
              Text(text = "Jitter", fontSize = 11.sp, color = TextMuted)
              Text(text = "1~2 ms", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
            }
          }

          // Packet Loss
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(GamingDarkBg)
              .padding(10.dp)
          ) {
            Column {
              Text(text = "Packet Loss", fontSize = 11.sp, color = TextMuted)
              Text(text = "0.0%", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
            }
          }

          // MTU
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(GamingDarkBg)
              .padding(10.dp)
          ) {
            Column {
              Text(text = "Fast MTU", fontSize = 11.sp, color = TextMuted)
              Text(text = "1420", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = GamingGold)
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Gaming Servers Quick Benchmark
    Text(
      text = if (language == "bn") "গেমিং সার্ভার পিং তুলনা" else "Gaming Servers Ping Comparison",
      fontSize = 15.sp,
      fontWeight = FontWeight.Bold,
      color = TextPrimary
    )
    Spacer(modifier = Modifier.height(8.dp))

    gamingServers.take(4).forEach { server ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
          .clip(RoundedCornerShape(12.dp))
          .clickable {
            VpnRepository.selectServer(server)
            onNavigateToServers()
          },
        colors = CardDefaults.cardColors(containerColor = GamingCardBg),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(
            if (currentServer.id == server.id) listOf(NeonGreen, CyberCyan)
            else listOf(GamingBorder, GamingBorder)
          )
        )
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = server.flagEmoji, fontSize = 24.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (language == "bn") server.nameBn else server.name,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = "${server.city} • Load: ${server.loadPercent}%",
                fontSize = 11.sp,
                color = TextMuted
              )
            }
          }
          PingBadge(pingMs = server.pingMs)
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Gaming DNS Selector
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, GamingBorder)))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Dns,
            contentDescription = "DNS",
            tint = CyberCyan,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (language == "bn") "গেমিং ডিএনএস সিলেক্টর" else "Gaming DNS Selector",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        listOf(
          "1.1.1.1 (Cloudflare Gaming - Recommended)",
          "8.8.8.8 (Google Low Latency)",
          "9.9.9.9 (Quad9 Secure Gaming)"
        ).forEach { dnsOption ->
          val isSelected = selectedDns.startsWith(dnsOption.take(7))
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .clickable { VpnRepository.setDns(dnsOption) }
              .padding(vertical = 8.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
              contentDescription = dnsOption,
              tint = if (isSelected) NeonGreen else TextMuted,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = dnsOption,
              fontSize = 12.sp,
              color = if (isSelected) TextPrimary else TextSecondary
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Fair Play & Safety Notice
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = GamingDarkBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, GamingBorder)))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
        verticalAlignment = Alignment.Top
      ) {
        Icon(
          imageVector = Icons.Default.Info,
          contentDescription = "Notice",
          tint = TextMuted,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (language == "bn")
            "নোটিশ: FF VPN শুধুমাত্র নিরাপদ নেটওয়ার্ক টানেলিং ও সর্বোত্তম গেমিং রুট নিশ্চিত করে। এটি ফ্রি ফায়ারের কোনো গেম ফাইল পরিবর্তন করে না এবং কোনো অনৈতিক সুবিধা প্রদান করে না।"
          else
            "Notice: FF VPN provides encrypted network routing. It does not modify game files or offer unfair advantages.",
          fontSize = 11.sp,
          color = TextMuted,
          lineHeight = 16.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))
  }
}
