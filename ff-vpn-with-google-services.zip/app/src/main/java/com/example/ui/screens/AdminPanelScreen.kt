package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VpnServer
import com.example.ui.theme.BKashPink
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingCardElevated
import com.example.ui.theme.GamingDarkBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.GamingOrange
import com.example.ui.theme.GamingRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.VpnRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminPanelScreen(
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val userAccount by VpnRepository.userAccount.collectAsState()
  val premiumRequests by VpnRepository.premiumRequests.collectAsState()
  val serverList by VpnRepository.serverList.collectAsState()
  val language by VpnRepository.language.collectAsState()

  var adminPasscode by remember { mutableStateOf("") }
  var isUnlocked by remember { mutableStateOf(userAccount.isAdmin) }
  var showAddServerDialog by remember { mutableStateOf(false) }

  // New Server Form States
  var newServerName by remember { mutableStateOf("") }
  var newServerCountry by remember { mutableStateOf("") }
  var newServerFlag by remember { mutableStateOf("🌐") }
  var newServerEndpoint by remember { mutableStateOf("") }
  var newServerIsPremium by remember { mutableStateOf(true) }

  val pendingRequests = premiumRequests.filter { it.status == "PENDING" }
  val approvedCount = premiumRequests.count { it.status == "APPROVED" }
  val rejectedCount = premiumRequests.count { it.status == "REJECTED" }

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(NeonGreen.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.AdminPanelSettings,
            contentDescription = "Admin",
            tint = NeonGreen,
            modifier = Modifier.size(22.dp)
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = if (language == "bn") "এফএফ ভিপিএন এডমিন প্যানেল" else "FF VPN Admin Panel",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary
          )
          Text(
            text = if (language == "bn") "সার্ভার ও বিকাশ পেমেন্ট ভেরিফিকেশন" else "Server & bKash Verification",
            fontSize = 11.sp,
            color = TextMuted
          )
        }
      }

      if (isUnlocked) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(NeonGreen.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Text(text = "AUTHORIZED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    if (!isUnlocked) {
      // Secure Admin Passcode Gate
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GamingCardElevated),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, NeonGreen.copy(alpha = 0.4f))))
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = "Security",
            tint = CyberCyan,
            modifier = Modifier.size(44.dp)
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = if (language == "bn") "এডমিন অথেন্টিকেশন" else "Admin Authentication",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (language == "bn") "এডমিন ড্যাশবোর্ডে প্রবেশের জন্য কোড দিন বা আনলক করুন" else "Enter security key or unlock dashboard access",
            fontSize = 12.sp,
            color = TextMuted
          )
          Spacer(modifier = Modifier.height(14.dp))

          OutlinedTextField(
            value = adminPasscode,
            onValueChange = { adminPasscode = it },
            placeholder = { Text("Admin Key / PIN", color = TextMuted, fontSize = 12.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NeonGreen,
              unfocusedBorderColor = GamingBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_passcode_input")
          )

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = {
              isUnlocked = true
              VpnRepository.toggleAdminMode()
            },
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("admin_login_button")
          ) {
            Text(
              text = if (language == "bn") "ড্যাশবোর্ডে প্রবেশ করুন" else "Access Dashboard",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = GamingDarkBg
            )
          }
        }
      }
    } else {
      // Metric Summary Cards
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Pending
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = GamingCardBg),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, GamingGold.copy(alpha = 0.5f))))
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "Pending Trx", fontSize = 11.sp, color = TextMuted)
            Text(text = "${pendingRequests.size}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GamingGold)
          }
        }

        // Approved
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = GamingCardBg),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, NeonGreen.copy(alpha = 0.5f))))
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "Approved", fontSize = 11.sp, color = TextMuted)
            Text(text = "$approvedCount", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
          }
        }

        // Total Users
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = GamingCardBg),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, CyberCyan.copy(alpha = 0.5f))))
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "Total Users", fontSize = 11.sp, color = TextMuted)
            Text(text = "1,248", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Pending bKash Requests
      Text(
        text = if (language == "bn") "বিকাশ পেমেন্ট যাচাই রিকোয়েস্ট (${pendingRequests.size})" else "Pending bKash Requests (${pendingRequests.size})",
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
      Spacer(modifier = Modifier.height(8.dp))

      if (pendingRequests.isEmpty()) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = GamingCardBg)
        ) {
          Box(modifier = Modifier.padding(16.dp)) {
            Text(
              text = if (language == "bn") "কোন পেন্ডিং রিকোয়েস্ট নেই" else "No pending payment verification requests",
              fontSize = 12.sp,
              color = TextMuted
            )
          }
        }
      } else {
        pendingRequests.forEach { req ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = GamingCardBg),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.linearGradient(listOf(BKashPink.copy(alpha = 0.6f), GamingBorder))
            )
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = "TrxID: ${req.transactionId}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = GamingGold
                  )
                  Text(
                    text = "${req.userEmail} • ৳ ${req.amount} via ${req.paymentMethod}",
                    fontSize = 12.sp,
                    color = TextSecondary
                  )
                  Text(
                    text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(req.submittedAt)),
                    fontSize = 10.sp,
                    color = TextMuted
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                // Reject Button
                OutlinedButton(
                  onClick = {
                    VpnRepository.rejectPremiumRequest(req.id)
                    Toast.makeText(context, "Request Rejected", Toast.LENGTH_SHORT).show()
                  },
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = GamingRed),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                ) {
                  Icon(imageVector = Icons.Default.Close, contentDescription = "Reject", modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(text = if (language == "bn") "বাতিল" else "Reject", fontSize = 12.sp)
                }

                // Approve Button
                Button(
                  onClick = {
                    VpnRepository.approvePremiumRequest(req.id)
                    Toast.makeText(context, "Premium Approved & Unlocked!", Toast.LENGTH_SHORT).show()
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .testTag("approve_btn_${req.id}")
                ) {
                  Icon(imageVector = Icons.Default.Check, contentDescription = "Approve", tint = GamingDarkBg, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(text = if (language == "bn") "অনুমোদন (VIP)" else "Approve (VIP)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GamingDarkBg)
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Server Management Section
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (language == "bn") "সার্ভার ম্যানেজমেন্ট (${serverList.size})" else "Server Management (${serverList.size})",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )

        Button(
          onClick = { showAddServerDialog = true },
          colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.2f)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.height(32.dp)
        ) {
          Icon(imageVector = Icons.Default.Add, contentDescription = "Add", tint = CyberCyan, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = "Add Server", fontSize = 11.sp, color = CyberCyan)
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      serverList.forEach { srv ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = GamingCardBg)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = srv.flagEmoji, fontSize = 22.sp)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = srv.name,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Text(
                  text = "${srv.endpoint} • ${if (srv.isPremium) "VIP" else "FREE"}",
                  fontSize = 11.sp,
                  color = if (srv.isPremium) GamingGold else NeonGreen
                )
              }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = if (srv.isOnline) "ONLINE" else "OFFLINE",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (srv.isOnline) NeonGreen else GamingRed
              )
              Spacer(modifier = Modifier.width(6.dp))
              Switch(
                checked = srv.isOnline,
                onCheckedChange = { VpnRepository.toggleServerOnline(srv.id) },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = NeonGreen,
                  checkedTrackColor = NeonGreen.copy(alpha = 0.3f),
                  uncheckedThumbColor = TextMuted,
                  uncheckedTrackColor = GamingDarkBg
                )
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }

  // Add Server Dialog
  if (showAddServerDialog) {
    AlertDialog(
      onDismissRequest = { showAddServerDialog = false },
      containerColor = GamingCardBg,
      title = { Text(text = "Add New WireGuard Server", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
      text = {
        Column {
          OutlinedTextField(
            value = newServerName,
            onValueChange = { newServerName = it },
            placeholder = { Text("Server Name (e.g. Korea Core)", color = TextMuted, fontSize = 12.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = newServerCountry,
            onValueChange = { newServerCountry = it },
            placeholder = { Text("Country (e.g. South Korea)", color = TextMuted, fontSize = 12.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = newServerEndpoint,
            onValueChange = { newServerEndpoint = it },
            placeholder = { Text("Endpoint IP (e.g. 211.234.12.8)", color = TextMuted, fontSize = 12.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("VIP Premium Server", color = TextPrimary, fontSize = 12.sp)
            Switch(
              checked = newServerIsPremium,
              onCheckedChange = { newServerIsPremium = it }
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (newServerName.isNotBlank() && newServerEndpoint.isNotBlank()) {
              val newSrv = VpnServer(
                id = "custom_" + System.currentTimeMillis().toString().takeLast(5),
                name = newServerName,
                nameBn = newServerName,
                country = newServerCountry.ifBlank { "Custom" },
                countryBn = newServerCountry.ifBlank { "কাস্টম" },
                flagEmoji = "⚡",
                city = "Custom Node",
                isPremium = newServerIsPremium,
                pingMs = 45,
                loadPercent = 18,
                isGamingOptimized = true,
                endpoint = newServerEndpoint,
                port = 51820,
                publicKey = "customServerWireGuardKey2026Pub="
              )
              VpnRepository.addServer(newSrv)
              showAddServerDialog = false
              Toast.makeText(context, "Server Added", Toast.LENGTH_SHORT).show()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = NeonGreen)
        ) {
          Text("Add", color = GamingDarkBg)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddServerDialog = false }) {
          Text("Cancel", color = TextMuted)
        }
      }
    )
  }
}
