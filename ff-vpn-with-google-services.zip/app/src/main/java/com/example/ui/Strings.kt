package com.example.ui

object Strings {
  fun get(key: String, lang: String = "bn"): String {
    val isBn = lang == "bn"
    return when (key) {
      "app_title" -> if (isBn) "FF VPN" else "FF VPN"
      "app_subtitle" -> if (isBn) "গেমিং সুপারফাস্ট ভিপিএন" else "Gaming Superfast VPN"
      "connected" -> if (isBn) "কানেক্টেড" else "Connected"
      "connecting" -> if (isBn) "কানেক্ট হচ্ছে..." else "Connecting..."
      "disconnected" -> if (isBn) "ডিসকানেক্টেড" else "Disconnected"
      "disconnecting" -> if (isBn) "ডিসকানেক্ট হচ্ছে..." else "Disconnecting..."
      "tap_to_connect" -> if (isBn) "কানেক্ট করতে ট্যাপ করুন" else "Tap to Connect"
      "tap_to_disconnect" -> if (isBn) "ডিসকানেক্ট করতে ট্যাপ করুন" else "Tap to Disconnect"
      "selected_server" -> if (isBn) "নির্বাচিত সার্ভার" else "Selected Server"
      "change_server" -> if (isBn) "সার্ভার পরিবর্তন" else "Change Server"
      "ping" -> if (isBn) "পিং" else "Ping"
      "download" -> if (isBn) "ডাউনলোড" else "Download"
      "upload" -> if (isBn) "আপলোড" else "Upload"
      "duration" -> if (isBn) "সময়কাল" else "Duration"
      "gaming_mode" -> if (isBn) "ফ্রি ফায়ার গেমিং অপটিমাইজার" else "Free Fire Gaming Optimizer"
      "gaming_mode_desc" -> if (isBn) "লো পিং ও কম জিটার মোড সক্রিয়" else "Low ping & jitter reduction active"
      "servers" -> if (isBn) "সার্ভারসমূহ" else "Servers"
      "free_servers" -> if (isBn) "ফ্রি সার্ভার" else "Free Servers"
      "premium_servers" -> if (isBn) "ভিআইপি প্রিমিয়াম সার্ভার" else "VIP Premium Servers"
      "upgrade_premium" -> if (isBn) "প্রিমিয়াম নিন (৩০০ টাকা)" else "Upgrade Premium (300 BDT)"
      "premium_badge" -> if (isBn) "প্রিমিয়াম" else "PREMIUM"
      "free_badge" -> if (isBn) "ফ্রি" else "FREE"
      "online" -> if (isBn) "অনলাইন" else "Online"
      "offline" -> if (isBn) "অফলাইন" else "Offline"
      "load" -> if (isBn) "লোড" else "Load"
      "nav_home" -> if (isBn) "হোম" else "Home"
      "nav_servers" -> if (isBn) "সার্ভার" else "Servers"
      "nav_booster" -> if (isBn) "গেমিং" else "Booster"
      "nav_premium" -> if (isBn) "প্রিমিয়াম" else "Premium"
      "nav_profile" -> if (isBn) "প্রোফাইল" else "Profile"
      "admin_panel" -> if (isBn) "এডমিন প্যানেল" else "Admin Panel"
      "bkash_number" -> if (isBn) "০১৭৭০১১০১৫৪" else "01770110154"
      "bkash_instructions" -> if (isBn)
        "১. আপনার বিকাশ অ্যাপ থেকে Send Money অপশনে যান।\n২. 01770110154 নম্বরে ৩০০ টাকা পাঠান।\n৩. সফল ট্রানজেকশনের Transaction ID কপি করুন।\n৪. নিচে TrxID পেস্ট করে সাবমিট করুন।"
      else
        "1. Open bKash and choose Send Money.\n2. Send 300 BDT to 01770110154.\n3. Copy the successful Transaction ID.\n4. Paste TrxID below and submit for instant verification."
      "trx_input_hint" -> if (isBn) "ট্রানজেকশন আইডি লিখুন (উদাঃ BL98AX7K)" else "Enter Transaction ID (e.g. BL98AX7K)"
      "submit_trx" -> if (isBn) "অনুরোধ জমা দিন" else "Submit Request"
      "payment_history" -> if (isBn) "পেমেন্ট ইতিহাস" else "Payment History"
      "pending" -> if (isBn) "যাচাই চলছে (Pending)" else "Pending Review"
      "approved" -> if (isBn) "অনুমোদিত (Approved)" else "Approved"
      "rejected" -> if (isBn) "বাতিল (Rejected)" else "Rejected"
      "copied" -> if (isBn) "নম্বর কপি করা হয়েছে!" else "bKash number copied!"
      "admin_mode" -> if (isBn) "এডমিন মোড" else "Admin Mode"
      else -> key
    }
  }
}
