package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val GamingColorScheme = darkColorScheme(
  primary = NeonGreen,
  onPrimary = GamingDarkBg,
  primaryContainer = NeonGreenDark,
  onPrimaryContainer = NeonGreenBright,
  secondary = CyberCyan,
  onSecondary = GamingDarkBg,
  secondaryContainer = CyberCyanDark,
  onSecondaryContainer = CyberCyan,
  tertiary = GamingGold,
  onTertiary = GamingDarkBg,
  background = GamingDarkBg,
  onBackground = TextPrimary,
  surface = GamingSurface,
  onSurface = TextPrimary,
  surfaceVariant = GamingCardBg,
  onSurfaceVariant = TextSecondary,
  outline = GamingBorder,
  error = GamingRed,
  onError = TextPrimary
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        window.statusBarColor = GamingDarkBg.toArgb()
        window.navigationBarColor = GamingDarkBg.toArgb()
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
      }
    }
  }

  MaterialTheme(
    colorScheme = GamingColorScheme,
    typography = Typography,
    content = content
  )
}
