package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.Strings
import com.example.ui.theme.BKashPink
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingCardElevated
import com.example.ui.theme.GamingDarkBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.GamingOrange
import com.example.ui.theme.GamingRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.VpnRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PremiumScreen(
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val userAccount by VpnRepository.userAccount.collectAsState()
  val premiumRequests by VpnRepository.premiumRequests.collectAsState()
  val language by VpnRepository.language.collectAsState()

  var transactionIdInput by remember { mutableStateOf("") }
  var submissionSuccessMsg by remember { mutableStateOf<String?>(null) }
  var submissionErrorMsg by remember { mutableStateOf<String?>(null) }

  val bKashNumber = "01770110154"

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = if (language == "bn") "ভিআইপি প্রিমিয়াম" else "VIP Premium",
          fontSize = 20.sp,
          fontWeight = FontWeight.Black,
          color = TextPrimary
        )
        Text(
          text = if (language == "bn") "বিকাশ সেন্ড মানি দিয়ে ৩০ দিনে আনলক করুন" else "Unlock 30 days VIP with bKash Send Money",
          fontSize = 12.sp,
          color = TextMuted
        )
      }

      if (userAccount.isPremium) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(NeonGreen.copy(alpha = 0.2f))
            .border(1.dp, NeonGreen, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = "VIP ACTIVE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = NeonGreen
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Pricing Hero Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardElevated),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = Brush.linearGradient(listOf(GamingGold, GamingOrange, BKashPink))
      )
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(BKashPink.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = "VIP",
                tint = GamingGold,
                modifier = Modifier.size(24.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (language == "bn") "প্রিমিয়াম গেমার প্যাক" else "Premium Gamer Pass",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = if (language == "bn") "মেয়াদ: ৩০ দিন" else "Duration: 30 Days",
                fontSize = 12.sp,
                color = TextMuted
              )
            }
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = if (language == "bn") "৳ ৩০০" else "300 BDT",
              fontSize = 22.sp,
              fontWeight = FontWeight.Black,
              color = GamingGold
            )
            Text(
              text = "bKash Send Money",
              fontSize = 10.sp,
              color = BKashPink,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = GamingBorder)
        Spacer(modifier = Modifier.height(12.dp))

        // Perks
        listOf(
          (if (language == "bn") "৭টি ডেডিকেটেড প্রিমিয়াম সার্ভার (USA, Brazil, UAE, Japan ইত্যাদি)" else "7 Dedicated VIP Servers (USA, Brazil, UAE, Japan etc.)"),
          (if (language == "bn") "ফ্রি ফায়ারে ০% প্যাকেট লস ও আল্ট্রা লো পিং রুট" else "0% Packet Loss & Ultra Low Ping Gaming Routing"),
          (if (language == "bn") "আনলিমিটেড ওয়্যারগার্ড ব্যান্ডউইডথ ও নো স্পিড লিমিট" else "Unlimited WireGuard Bandwidth with No Throttling")
        ).forEach { perk ->
          Row(
            modifier = Modifier.padding(vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "Check",
              tint = NeonGreen,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = perk, fontSize = 12.sp, color = TextPrimary)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // bKash Number Box with 1-Tap Copy
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardBg),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = Brush.linearGradient(listOf(BKashPink, BKashPink.copy(alpha = 0.5f)))
      )
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(BKashPink),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "বিকাশ",
              fontSize = 11.sp,
              fontWeight = FontWeight.Black,
              color = Color.White
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = if (language == "bn") "বিকাশ পার্সোনাল নম্বর (Send Money)" else "bKash Personal (Send Money)",
              fontSize = 11.sp,
              color = TextMuted
            )
            Text(
              text = bKashNumber,
              fontSize = 18.sp,
              fontWeight = FontWeight.ExtraBold,
              color = TextPrimary,
              letterSpacing = 1.sp
            )
          }
        }

        Button(
          onClick = {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("bKash Number", bKashNumber))
            Toast.makeText(context, Strings.get("copied", language), Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = BKashPink),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("copy_bkash_number_button")
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Copy",
            tint = Color.White,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = if (language == "bn") "কপি" else "Copy", fontSize = 12.sp, color = Color.White)
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Step by step Instructions Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, GamingBorder)))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp)
      ) {
        Text(
          text = if (language == "bn") "পেমেন্ট নির্দেশিকা" else "Payment Instructions",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = CyberCyan
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = Strings.get("bkash_instructions", language),
          fontSize = 12.sp,
          color = TextSecondary,
          lineHeight = 19.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Transaction ID Input Form
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, NeonGreen.copy(alpha = 0.3f))))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp)
      ) {
        Text(
          text = if (language == "bn") "ট্রানজেকশন আইডি জমা দিন" else "Submit Transaction ID",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = transactionIdInput,
          onValueChange = {
            transactionIdInput = it.uppercase()
            submissionSuccessMsg = null
            submissionErrorMsg = null
          },
          placeholder = {
            Text(text = Strings.get("trx_input_hint", language), fontSize = 12.sp, color = TextMuted)
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Characters,
            imeAction = ImeAction.Done
          ),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonGreen,
            unfocusedBorderColor = GamingBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("transaction_id_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        Button(
          onClick = {
            if (transactionIdInput.trim().length >= 8) {
              val ok = VpnRepository.submitPremiumRequest(transactionIdInput)
              if (ok) {
                submissionSuccessMsg = if (language == "bn")
                  "অনুরোধ সফলভাবে জমা হয়েছে! এডমিন অনুমোদনের সাথে সাথে প্রিমিয়াম চালু হবে।"
                else
                  "Request submitted successfully! Premium will activate once admin approves."
                transactionIdInput = ""
              }
            } else {
              submissionErrorMsg = if (language == "bn")
                "অনুগ্রহ করে সঠিক বিকাশ ট্রানজেকশন আইডি লিখুন (কমপক্ষে ৮ অক্ষর)"
              else
                "Please enter a valid bKash Transaction ID (at least 8 chars)"
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .testTag("submit_trx_button")
        ) {
          Icon(
            imageVector = Icons.Default.Send,
            contentDescription = "Submit",
            tint = GamingDarkBg,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = Strings.get("submit_trx", language),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = GamingDarkBg
          )
        }

        submissionSuccessMsg?.let { msg ->
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = msg, fontSize = 12.sp, color = NeonGreen)
        }

        submissionErrorMsg?.let { err ->
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = err, fontSize = 12.sp, color = GamingRed)
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Payment History List
    Text(
      text = Strings.get("payment_history", language),
      fontSize = 16.sp,
      fontWeight = FontWeight.Bold,
      color = TextPrimary
    )
    Spacer(modifier = Modifier.height(8.dp))

    if (premiumRequests.isEmpty()) {
      Text(
        text = if (language == "bn") "কোন পেমেন্ট হিস্ট্রি নেই" else "No payment requests yet",
        fontSize = 12.sp,
        color = TextMuted
      )
    } else {
      premiumRequests.forEach { req ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = GamingCardBg),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, GamingBorder)))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "TrxID: ${req.transactionId}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = "৳ ${req.amount} via ${req.paymentMethod} • ${SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(req.submittedAt))}",
                fontSize = 11.sp,
                color = TextMuted
              )
            }

            // Status Badge
            val (badgeBg, badgeText, statusLabel) = when (req.status) {
              "APPROVED" -> Triple(NeonGreen.copy(alpha = 0.2f), NeonGreen, Strings.get("approved", language))
              "REJECTED" -> Triple(GamingRed.copy(alpha = 0.2f), GamingRed, Strings.get("rejected", language))
              else -> Triple(GamingGold.copy(alpha = 0.2f), GamingGold, Strings.get("pending", language))
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(badgeBg)
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = statusLabel,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = badgeText
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}
