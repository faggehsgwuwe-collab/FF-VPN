package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonGreen = Color(0xFF00FF66)
val NeonGreenBright = Color(0xFF10E575)
val NeonGreenGlow = Color(0x3300FF66)
val NeonGreenDark = Color(0xFF003816)

val CyberCyan = Color(0xFF00F0FF)
val CyberCyanDark = Color(0xFF00363A)

val GamingDarkBg = Color(0xFF080B11)
val GamingSurface = Color(0xFF0E1420)
val GamingCardBg = Color(0xFF131D2D)
val GamingCardElevated = Color(0xFF1A263B)
val GamingBorder = Color(0xFF23354E)
val GamingBorderGlow = Color(0xFF00FF66).copy(alpha = 0.4f)

val GamingGold = Color(0xFFFFB800)
val GamingRed = Color(0xFFFF3366)
val GamingOrange = Color(0xFFFF6B00)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val BKashPink = Color(0xFFE2136E)
