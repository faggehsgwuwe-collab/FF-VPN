package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionState
import com.example.ui.Strings
import com.example.ui.components.GamingStatCard
import com.example.ui.components.PingBadge
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingCardElevated
import com.example.ui.theme.GamingDarkBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.GamingOrange
import com.example.ui.theme.GamingRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.VpnRepository

@Composable
fun HomeScreen(
  vpnLauncher: ActivityResultLauncher<Intent>?,
  onNavigateToServers: () -> Unit,
  onNavigateToPremium: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val connectionState by VpnRepository.connectionState.collectAsState()
  val currentServer by VpnRepository.currentServer.collectAsState()
  val trafficStats by VpnRepository.trafficStats.collectAsState()
  val userAccount by VpnRepository.userAccount.collectAsState()
  val language by VpnRepository.language.collectAsState()
  val gamingMode by VpnRepository.gamingModeEnabled.collectAsState()
  val errorMessage by VpnRepository.errorMessage.collectAsState()

  val isConnected = connectionState == ConnectionState.CONNECTED
  val isConnecting = connectionState == ConnectionState.CONNECTING

  val infiniteTransition = rememberInfiniteTransition(label = "pulse_transition")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = if (isConnected || isConnecting) 1.12f else 1.02f,
    animationSpec = infiniteRepeatable(
      animation = tween(1400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_scale"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Error Alert if any
    AnimatedVisibility(visible = errorMessage != null) {
      errorMessage?.let { error ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
          colors = CardDefaults.cardColors(containerColor = GamingRed.copy(alpha = 0.15f)),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingRed, GamingRed.copy(alpha = 0.5f))))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.ErrorOutline,
              contentDescription = "Error",
              tint = GamingRed,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = error,
              fontSize = 13.sp,
              color = TextPrimary
            )
          }
        }
      }
    }

    // Server Selection Card
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .clickable { onNavigateToServers() }
        .testTag("selected_server_card"),
      colors = CardDefaults.cardColors(containerColor = GamingCardBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, NeonGreen.copy(alpha = 0.2f))))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = currentServer.flagEmoji, fontSize = 28.sp)
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = if (language == "bn") currentServer.nameBn else currentServer.name,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              if (currentServer.isPremium) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(GamingGold.copy(alpha = 0.2f))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = "VIP",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    color = GamingGold
                  )
                }
              }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "${currentServer.city} | ${currentServer.endpoint}",
              fontSize = 12.sp,
              color = TextMuted
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          PingBadge(pingMs = if (isConnected) trafficStats.currentPingMs.coerceAtLeast(10) else currentServer.pingMs)
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "Select",
            tint = TextSecondary,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(28.dp))

    // Big Glowing Center Connect Button
    Box(
      modifier = Modifier
        .size(230.dp),
      contentAlignment = Alignment.Center
    ) {
      // Outer Glowing Ripples
      if (isConnected || isConnecting) {
        Box(
          modifier = Modifier
            .size(230.dp)
            .scale(pulseScale)
            .clip(CircleShape)
            .background(NeonGreen.copy(alpha = 0.08f))
            .border(2.dp, NeonGreen.copy(alpha = 0.35f), CircleShape)
        )
      }

      // Middle Ring
      Box(
        modifier = Modifier
          .size(190.dp)
          .clip(CircleShape)
          .background(GamingCardElevated)
          .border(
            3.dp,
            if (isConnected) NeonGreen else if (isConnecting) CyberCyan else GamingBorder,
            CircleShape
          )
      )

      // Inner Clickable Power Core
      Box(
        modifier = Modifier
          .size(150.dp)
          .clip(CircleShape)
          .background(
            Brush.radialGradient(
              listOf(
                if (isConnected) NeonGreen.copy(alpha = 0.25f)
                else if (isConnecting) CyberCyan.copy(alpha = 0.2f)
                else GamingDarkBg,
                GamingCardBg
              )
            )
          )
          .clickable {
            if (isConnected || isConnecting) {
              VpnRepository.stopVpn(context)
            } else {
              if (currentServer.isPremium && !userAccount.isPremium) {
                onNavigateToPremium()
              } else {
                VpnRepository.startVpn(context, vpnLauncher)
              }
            }
          }
          .testTag("vpn_power_button"),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          if (isConnecting) {
            CircularProgressIndicator(
              modifier = Modifier.size(46.dp),
              color = CyberCyan,
              strokeWidth = 3.dp
            )
          } else {
            Icon(
              imageVector = Icons.Default.PowerSettingsNew,
              contentDescription = "Connect / Disconnect",
              tint = if (isConnected) NeonGreen else TextSecondary,
              modifier = Modifier.size(52.dp)
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = when (connectionState) {
              ConnectionState.CONNECTED -> Strings.get("connected", language)
              ConnectionState.CONNECTING -> Strings.get("connecting", language)
              ConnectionState.DISCONNECTING -> Strings.get("disconnecting", language)
              else -> Strings.get("disconnected", language)
            },
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isConnected) NeonGreen else TextSecondary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Connection Duration Timer
    if (isConnected) {
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(NeonGreen.copy(alpha = 0.12f))
          .border(1.dp, NeonGreen.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
          .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Timer,
          contentDescription = "Duration",
          tint = NeonGreen,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = trafficStats.formatDuration(),
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = NeonGreen
        )
      }
    } else {
      Text(
        text = Strings.get("tap_to_connect", language),
        fontSize = 13.sp,
        color = TextMuted
      )
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Gaming Mode Switch Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, CyberCyan.copy(alpha = 0.3f))))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(GamingOrange.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.SportsEsports,
              contentDescription = "Gaming",
              tint = GamingOrange,
              modifier = Modifier.size(22.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = Strings.get("gaming_mode", language),
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = Strings.get("gaming_mode_desc", language),
              fontSize = 11.sp,
              color = TextMuted
            )
          }
        }
        Switch(
          checked = gamingMode,
          onCheckedChange = { VpnRepository.toggleGamingMode(it) },
          colors = SwitchDefaults.colors(
            checkedThumbColor = NeonGreen,
            checkedTrackColor = NeonGreen.copy(alpha = 0.3f),
            uncheckedThumbColor = TextMuted,
            uncheckedTrackColor = GamingDarkBg
          ),
          modifier = Modifier.testTag("gaming_mode_switch")
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Traffic Stats Row (Download & Upload)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      GamingStatCard(
        title = Strings.get("download", language),
        value = if (isConnected) trafficStats.formatSpeed(trafficStats.downloadSpeedBps) else "0.0 KB/s",
        subtitle = "Total: " + trafficStats.formatBytes(trafficStats.totalBytesDownloaded),
        icon = Icons.Default.CloudDownload,
        accentColor = CyberCyan,
        modifier = Modifier
          .weight(1f)
          .testTag("download_stat_card")
      )

      GamingStatCard(
        title = Strings.get("upload", language),
        value = if (isConnected) trafficStats.formatSpeed(trafficStats.uploadSpeedBps) else "0.0 KB/s",
        subtitle = "Total: " + trafficStats.formatBytes(trafficStats.totalBytesUploaded),
        icon = Icons.Default.CloudUpload,
        accentColor = NeonGreen,
        modifier = Modifier
          .weight(1f)
          .testTag("upload_stat_card")
      )
    }

    // Premium Promo if not premium
    if (!userAccount.isPremium) {
      Spacer(modifier = Modifier.height(16.dp))
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .clickable { onNavigateToPremium() }
          .testTag("upgrade_premium_banner"),
        colors = CardDefaults.cardColors(containerColor = GamingGold.copy(alpha = 0.12f)),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingGold, GamingOrange)))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = "VIP",
              tint = GamingGold,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = Strings.get("upgrade_premium", language),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GamingGold
              )
              Text(
                text = if (language == "bn") "বিকাশে ৩০০ টাকায় আনলক করুন ১০টি দেশ" else "bKash 300 BDT to unlock all 10 countries",
                fontSize = 11.sp,
                color = TextSecondary
              )
            }
          }
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "Go",
            tint = GamingGold,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}
