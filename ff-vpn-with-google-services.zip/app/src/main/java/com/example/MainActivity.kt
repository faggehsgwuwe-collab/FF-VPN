package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.Strings
import com.example.ui.components.GamingTopBar
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.GamingBoosterScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PremiumScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.ServerListScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingDarkBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.FfVpnService
import com.example.vpn.VpnRepository

sealed class Screen(val index: Int) {
  object Home : Screen(0)
  object Servers : Screen(1)
  object Booster : Screen(2)
  object Premium : Screen(3)
  object Profile : Screen(4)
  object Admin : Screen(5)
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        FfVpnApp()
      }
    }
  }
}

@Composable
fun FfVpnApp() {
  val context = LocalContext.current
  val language by VpnRepository.language.collectAsState()
  val userAccount by VpnRepository.userAccount.collectAsState()

  var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }

  // VPN Permission Launcher
  val vpnLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      val serviceIntent = Intent(context, FfVpnService::class.java).apply {
        action = FfVpnService.ACTION_CONNECT
        putExtra(FfVpnService.EXTRA_SERVER_ID, VpnRepository.currentServer.value.id)
      }
      context.startService(serviceIntent)
    }
  }

  // Notification Permission Launcher (Android 13+)
  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { _ -> }

  LaunchedEffect(Unit) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
  }

  BackHandler(enabled = currentScreen != Screen.Home) {
    currentScreen = Screen.Home
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .background(GamingDarkBg),
    containerColor = GamingDarkBg,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      GamingTopBar(
        lang = language,
        isAdmin = userAccount.isAdmin,
        onToggleLang = {
          VpnRepository.setLanguage(if (language == "bn") "en" else "bn")
        },
        onToggleAdmin = {
          currentScreen = if (currentScreen == Screen.Admin) Screen.Home else Screen.Admin
        }
      )
    },
    bottomBar = {
      if (currentScreen != Screen.Admin) {
        val navItems = listOf(
          Triple(Screen.Home, Strings.get("nav_home", language), Icons.Default.Home),
          Triple(Screen.Servers, Strings.get("nav_servers", language), Icons.Default.Dns),
          Triple(Screen.Booster, Strings.get("nav_booster", language), Icons.Default.SportsEsports),
          Triple(Screen.Premium, Strings.get("nav_premium", language), Icons.Default.Star),
          Triple(Screen.Profile, Strings.get("nav_profile", language), Icons.Default.Person)
        )

        NavigationBar(
          containerColor = GamingCardBg,
          contentColor = NeonGreen,
          modifier = Modifier
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .border(1.dp, GamingBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
        ) {
          navItems.forEach { (screen, title, icon) ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
              selected = isSelected,
              onClick = { currentScreen = screen },
              icon = {
                Icon(
                  imageVector = icon,
                  contentDescription = title,
                  tint = if (isSelected) NeonGreen else TextMuted,
                  modifier = Modifier.size(22.dp)
                )
              },
              label = {
                Text(
                  text = title,
                  fontSize = 10.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) NeonGreen else TextMuted
                )
              },
              colors = NavigationBarItemDefaults.colors(
                indicatorColor = NeonGreen.copy(alpha = 0.15f),
                selectedIconColor = NeonGreen,
                selectedTextColor = NeonGreen,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
              ),
              modifier = Modifier.testTag("nav_item_${title.lowercase()}")
            )
          }
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentScreen) {
        is Screen.Home -> HomeScreen(
          vpnLauncher = vpnLauncher,
          onNavigateToServers = { currentScreen = Screen.Servers },
          onNavigateToPremium = { currentScreen = Screen.Premium }
        )
        is Screen.Servers -> ServerListScreen(
          vpnLauncher = vpnLauncher,
          onNavigateToPremium = { currentScreen = Screen.Premium }
        )
        is Screen.Booster -> GamingBoosterScreen(
          onNavigateToServers = { currentScreen = Screen.Servers }
        )
        is Screen.Premium -> PremiumScreen()
        is Screen.Profile -> ProfileSettingsScreen(
          onNavigateToPremium = { currentScreen = Screen.Premium },
          onNavigateToAdmin = { currentScreen = Screen.Admin }
        )
        is Screen.Admin -> AdminPanelScreen()
      }
    }
  }
}
