package com.example.model

enum class ConnectionState {
  DISCONNECTED,
  CONNECTING,
  CONNECTED,
  DISCONNECTING,
  ERROR
}

data class TrafficStats(
  val uploadSpeedBps: Long = 0L,
  val downloadSpeedBps: Long = 0L,
  val totalBytesUploaded: Long = 0L,
  val totalBytesDownloaded: Long = 0L,
  val connectionDurationSeconds: Long = 0L,
  val currentPingMs: Int = 0
) {
  fun formatDuration(): String {
    val hours = connectionDurationSeconds / 3600
    val minutes = (connectionDurationSeconds % 3600) / 60
    val seconds = connectionDurationSeconds % 60
    return if (hours > 0) {
      String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
      String.format("%02d:%02d", minutes, seconds)
    }
  }

  fun formatSpeed(bytesPerSec: Long): String {
    val kb = bytesPerSec / 1024.0
    return if (kb >= 1024.0) {
      String.format("%.1f MB/s", kb / 1024.0)
    } else {
      String.format("%.1f KB/s", kb)
    }
  }

  fun formatBytes(bytes: Long): String {
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
      gb >= 1.0 -> String.format("%.2f GB", gb)
      mb >= 1.0 -> String.format("%.1f MB", mb)
      else -> String.format("%.0f KB", kb)
    }
  }
}
