package com.example.model

data class VpnServer(
  val id: String,
  val name: String,
  val nameBn: String,
  val country: String,
  val countryBn: String,
  val flagEmoji: String,
  val city: String,
  val isPremium: Boolean,
  val pingMs: Int,
  val loadPercent: Int,
  val isGamingOptimized: Boolean,
  val endpoint: String,
  val port: Int = 51820,
  val publicKey: String,
  val allowedIps: String = "0.0.0.0/0, ::/0",
  val dns: String = "1.1.1.1, 1.0.0.1",
  val isOnline: Boolean = true
) {
  fun generateWireGuardConfig(clientPrivateKey: String, clientIp: String = "10.200.0.2/32"): String {
    return """
      [Interface]
      PrivateKey = $clientPrivateKey
      Address = $clientIp
      DNS = $dns
      MTU = 1420

      [Peer]
      PublicKey = $publicKey
      Endpoint = $endpoint:$port
      AllowedIPs = $allowedIps
      PersistentKeepalive = 25
    """.trimIndent()
  }
}
