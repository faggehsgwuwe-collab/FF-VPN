const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.database();

/**
 * Trigger when a user submits a premium request.
 * Validates format and notifies admins.
 */
exports.onPremiumRequestCreated = functions.database
  .ref("/premiumRequests/{requestId}")
  .onCreate(async (snapshot, context) => {
    const data = snapshot.val();
    const requestId = context.params.requestId;

    console.log(`[FF VPN] New Premium Request: ${requestId} by user ${data.userId} with TrxID: ${data.transactionId}`);

    // Basic server-side sanity check
    if (!data.transactionId || data.transactionId.length < 8) {
      return snapshot.ref.update({
        status: "REJECTED",
        adminNote: "Invalid Transaction ID format (less than 8 characters)"
      });
    }

    return null;
  });

/**
 * Trigger when an admin approves a request.
 * Automatically upgrades the user to Premium for 30 days!
 */
exports.onPremiumRequestUpdated = functions.database
  .ref("/premiumRequests/{requestId}")
  .onUpdate(async (change, context) => {
    const before = change.before.val();
    const after = change.after.val();

    if (before.status === "PENDING" && after.status === "APPROVED") {
      const userId = after.userId;
      const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
      const expiry = Date.now() + thirtyDaysMs;

      console.log(`[FF VPN] Activating 30-Day VIP for User: ${userId}`);

      await db.ref(`/users/${userId}`).update({
        premiumStatus: "ACTIVE",
        isPremium: true,
        premiumExpiry: expiry,
        approvedAt: Date.now()
      });
    }

    return null;
  });

/**
 * Callable function to get safe client WireGuard config.
 * Gated strictly by user Premium status for VIP servers.
 */
exports.getWireGuardClientConfig = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Authentication required");
  }

  const { serverId } = data;
  const serverSnap = await db.ref(`/servers/${serverId}`).once("value");
  const server = serverSnap.val();

  if (!server) {
    throw new functions.https.HttpsError("not-found", "Server not found");
  }

  if (server.premiumRequired) {
    const userSnap = await db.ref(`/users/${context.auth.uid}`).once("value");
    const user = userSnap.val();

    if (!user || !user.isPremium || user.premiumExpiry < Date.now()) {
      throw new functions.https.HttpsError(
        "permission-denied",
        "VIP subscription required to access this premium WireGuard node."
      );
    }
  }

  // Return safe client config
  return {
    endpoint: `${server.endpoint}:${server.port || 51820}`,
    serverPublicKey: server.publicKey,
    allowedIps: server.allowedIps || "0.0.0.0/0",
    dns: server.dns || "1.1.1.1, 8.8.8.8"
  };
});
