# FF VPN Cloud Functions (বাংলা)

## এই ফোল্ডারে কী আছে
- `approvePremiumRequest`: Admin custom claim `admin=true` থাকলে Pending request অনুমোদন করে এবং ৩০ দিনের Premium দেয়।
- `rejectPremiumRequest`: Admin request Reject করতে পারে।
- `getWireGuardClientConfig`: লগইন করা ব্যবহারকারীকে server config দেয়; Premium server-এর জন্য Premium expiry যাচাই করে।
- `onPremiumRequestCreated`: নতুন request-এর basic format যাচাই করে; পেমেন্ট নিজে থেকে approve করে না।

## গুরুত্বপূর্ণ
1. Firebase Authentication চালু করুন এবং Realtime Database-এ `firebase/database.rules.json` Rules Publish করুন।
2. Admin user-কে **বিশ্বস্ত server-side পরিবেশে** Firebase Admin SDK দিয়ে custom claim দিন: `{admin: true}`। কোনো Android client থেকে admin claim সেট করবেন না।
3. Functions deploy করতে Firebase CLI এবং billing/plan eligibility লাগতে পারে। `cd functions && npm install`, তারপর project root থেকে `firebase deploy --only functions`।
4. Android app-এ Firebase Auth ও Callable Functions যুক্ত না করা পর্যন্ত এই Functions app UI-তে কাজ করবে না। বর্তমান app-এর repository/screens এখনো demo/local state ব্যবহার করতে পারে।
5. WireGuard config-এ server private key কখনো রাখবেন না। এই function শুধু endpoint, public key ও routing settings ফেরত দেয়। বাস্তব VPN চালাতে বৈধ WireGuard server ও Android tunnel integration দরকার।
6. bKash Transaction ID বাস্তবে Admin-কে যাচাই করতে হবে; শুধু ID format দিয়ে payment নিশ্চিত হয় না।
