const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onValueCreated } = require('firebase-functions/v2/database');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.database();
const PREMIUM_MS = 30 * 24 * 60 * 60 * 1000;

function requireAuth(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Please sign in first.');
  return request.auth.uid;
}
function requireAdmin(request) {
  const uid = requireAuth(request);
  if (request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Admin access required.');
  return uid;
}

// Admin SDK runs this after a newly submitted request; it never approves payments automatically.
exports.onPremiumRequestCreated = onValueCreated('/premiumRequests/{requestId}', async (event) => {
  const request = event.data.val() || {};
  if (!request.userId || !request.transactionId || String(request.transactionId).trim().length < 8 ||
      Number(request.amount) !== 300 || request.status !== 'PENDING') {
    await event.data.ref.update({ status: 'REJECTED', adminNote: 'Invalid request data', reviewedAt: Date.now() });
  }
});

// Only a trusted Admin custom claim can approve. Client cannot set premium fields directly.
exports.approvePremiumRequest = onCall(async (request) => {
  requireAdmin(request);
  const requestId = String(request.data?.requestId || '').trim();
  if (!requestId) throw new HttpsError('invalid-argument', 'requestId is required.');
  const ref = db.ref(`/premiumRequests/${requestId}`);
  const snap = await ref.get();
  if (!snap.exists()) throw new HttpsError('not-found', 'Premium request not found.');
  const req = snap.val();
  if (req.status !== 'PENDING') throw new HttpsError('failed-precondition', 'Request is not pending.');
  if (!req.userId) throw new HttpsError('failed-precondition', 'Request has no userId.');
  const now = Date.now();
  const expiry = now + PREMIUM_MS;
  const updates = {};
  updates[`premiumRequests/${requestId}/status`] = 'APPROVED';
  updates[`premiumRequests/${requestId}/reviewedAt`] = now;
  updates[`premiumRequests/${requestId}/reviewedBy`] = request.auth.uid;
  updates[`users/${req.userId}/premiumStatus`] = 'ACTIVE';
  updates[`users/${req.userId}/isPremium`] = true;
  updates[`users/${req.userId}/premiumExpiry`] = expiry;
  updates[`users/${req.userId}/premiumExpiryDate`] = expiry;
  updates[`users/${req.userId}/approvedAt`] = now;
  await db.ref().update(updates);
  return { success: true, premiumExpiry: expiry };
});

exports.rejectPremiumRequest = onCall(async (request) => {
  requireAdmin(request);
  const requestId = String(request.data?.requestId || '').trim();
  const note = String(request.data?.note || 'Payment could not be verified').slice(0, 300);
  if (!requestId) throw new HttpsError('invalid-argument', 'requestId is required.');
  const ref = db.ref(`/premiumRequests/${requestId}`);
  const snap = await ref.get();
  if (!snap.exists()) throw new HttpsError('not-found', 'Premium request not found.');
  if (snap.val().status !== 'PENDING') throw new HttpsError('failed-precondition', 'Request is not pending.');
  await ref.update({ status: 'REJECTED', adminNote: note, reviewedAt: Date.now(), reviewedBy: request.auth.uid });
  return { success: true };
});

// Server configuration is returned only after authentication and Premium verification.
exports.getWireGuardClientConfig = onCall(async (request) => {
  const uid = requireAuth(request);
  const serverId = String(request.data?.serverId || '').trim();
  if (!serverId) throw new HttpsError('invalid-argument', 'serverId is required.');
  const serverSnap = await db.ref(`/servers/${serverId}`).get();
  const server = serverSnap.val();
  if (!server || server.isOnline === false) throw new HttpsError('not-found', 'Server unavailable.');
  if (server.premiumRequired === true) {
    const user = (await db.ref(`/users/${uid}`).get()).val() || {};
    if (user.isPremium !== true || Number(user.premiumExpiry || user.premiumExpiryDate || 0) <= Date.now()) {
      throw new HttpsError('permission-denied', 'An active Premium subscription is required.');
    }
  }
  // Never store or return a server private key to the app.
  if (!server.endpoint || !server.publicKey || !server.port) throw new HttpsError('failed-precondition', 'Server config incomplete.');
  return { endpoint: `${server.endpoint}:${server.port}`, serverPublicKey: server.publicKey,
    allowedIps: server.allowedIps || '0.0.0.0/0', dns: server.dns || '1.1.1.1, 8.8.8.8' };
});
